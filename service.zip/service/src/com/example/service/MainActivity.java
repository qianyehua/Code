package com.example.service;
import com.example.service.R;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	    Button buttonStart, buttonPause,buttonExit,buttonStop;  
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonStart=(Button)findViewById(R.id.buttonStart);
        buttonPause=(Button)findViewById(R.id.buttonPause);
        buttonStop=(Button)findViewById(R.id.buttonStop);
        buttonExit=(Button)findViewById(R.id.buttonExit);	
        
        
        
        buttonStart.setOnClickListener(new OnClickListener() {		
      			@Override
      			public void onClick(View v) {
      				Intent intent = new Intent();
      intent.setAction("com.example.service.MyService");
      				// TODO Auto-generated method stub
      				intent.putExtra("op", 1);
      				startService(intent);
      			}
      		});
        
        
      		buttonPause.setOnClickListener(new OnClickListener() {		
      			@Override
      			public void onClick(View v) {
      				Intent intent = new Intent();
      				intent.setAction("com.example.service.MyService");
      				// TODO Auto-generated method stub
      				intent.putExtra("op", 2);
      				stopService(intent);
      			}
      		});
      		
      		
      		buttonStop.setOnClickListener(new OnClickListener() {		
      			@Override
      			public void onClick(View v) {
      				// TODO Auto-generated method stub
      				MainActivity.this.finish();
      			}
      		});
      		
      		
      		buttonExit.setOnClickListener(new OnClickListener() {		
      			@Override
      			public void onClick(View v) {
      				Intent intent = new Intent();
      				intent.setAction("com.example.service.MyService");
      				// TODO Auto-generated method stub
      				stopService(intent);
      			}
      		});	
      	}
    
    
    public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
}

