package com.example.service;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class MyService extends Service { 
	MediaPlayer mp;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onCreate() {    
    	// TODO Auto-generated method stub
    	super.onCreate();
    	mp = MediaPlayer.create(MyService.this, R.raw.ex6);
    }
    @Override
    public void onDestroy() {     
    	// TODO Auto-generated method stub
    	super.onDestroy();
    	if (mp!=null) {
            mp.stop();
            mp.release();
      }
}
private void play() {    
		// TODO Auto-generated method stub
		if (mp!=null&&!mp.isPlaying()) {
            mp.start();
      }
	}

    private void pause() {    
		// TODO Auto-generated method stub
    	if (mp!=null&&mp.isPlaying()) {
            mp.pause();
      }
	}
    @SuppressWarnings("deprecation")
	@Override
    public void onStart(Intent intent, int startId) {
    	// TODO Auto-generated method stub
    	super.onStart(intent, startId);
    	int op=intent.getIntExtra("op", 1);
    	switch (op) {     
		case 1:
			play();
			break;
		case 2:
			pause();
			break;
		}
    }
}
