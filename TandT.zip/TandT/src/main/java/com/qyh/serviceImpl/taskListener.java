package com.qyh.serviceImpl;

import java.util.List;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qyh.daoImpl.workFlowDaoImpl;
public class taskListener implements TaskListener{
	public void notify(DelegateTask delegateTask) {
		// TODO Auto-generated method stub
//    IEmployeeService employeeService=(IEmployeeService) SpringContextUtil.getBean("employeeService");
//		
//		List<Employee> list=employeeService.fingywglId();
		workFlowDaoImpl wf = SpringContextUtil.getBean("workFlowDaoImpl");

        for(int i=0;i<wf.getGl().size();i++){
//        	System.out.println("id"+list.size());
			delegateTask.addCandidateUser(wf.getGl().get(i).getId()+"");
		}
	}

}
