package com.qyh.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.activiti.engine.impl.util.json.JSONArray;
import org.activiti.engine.impl.util.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qyh.daoImpl.LoginDao;
import com.qyh.entity.Danwei;
import com.qyh.entity.User;

@Service
public class LoginSer{
 @Autowired 
 private LoginDao dao;
 public User getUser(String u,String p){  //获取用户表的所有数据
	 return dao.login(u, p).get(0);
 }
 public String Login(String u,String p){   //根据用户表查出的lxid 获取对应类型表里的用户类型跳转到对应的页面
	 if(dao.login(u, p).size()!=0){
		 return dao.getUserlx(getUser(u, p).getLxid()).getRole();
	 }
	 else return "index";
 }
 
 public Danwei getDanwei(int id){
	 return dao.getDanwei(id);
 }
 
 public List<User> getUser2(){
	 return dao.getUser();
 }
 
 public List<Danwei> getAlDanwei(){
	 return dao.getAlldanwei();
 }
 
 public User getUserbyid(int id){
	 	return dao.getUserbyid(id);
	 }

 public List<Map> getDanweiChoose(){
	 JSONArray array=new JSONArray();
	 JSONObject ob1=new JSONObject();
	 List<Map> li=new ArrayList<Map>();
	 ob1.put("id",0);
	 ob1.put("text", "选择乡镇");
	 ob1.put("selected",true);
	 array.put(ob1);
	 for(Danwei d:dao.getAllXiangzheng()){
		 Map ob=new HashMap();
		 ob.put("id", d.getId());
     	 ob.put("text", d.getName());
     	 li.add(ob);
	 }
     return li;
   }



	public int saveUser(User u){
		 if(dao.saveUser(u)==1){
			 return 1;
		 }
		 else return 0;
	 }
	 
	 public int saveDanwei(Danwei d){
		 if(dao.saveDanwei(d)==1){
			 return 1;
		 }
		 else return 0;
	 }
	public int  updateUserDanwei(int dwid,int id){
	 	
		 if(dao.updateUserDanwei(dwid, id)==1){
			 return 1;
		 }
		 else  return 0;
	 }
	public int deleUser(int id){
			return dao.deleUser(id);
		}
		
		public int deleDanwei(int id){
			return dao.deleDanwei(id);
		}
		
		public int updateUser(User u){
			  return dao.updateUser(u);
		  }
		  
public int updateDanweu(Danwei d){
			  return dao.updateDanwei(d);
		  }
}
