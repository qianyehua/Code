package com.qyh.serviceImpl;

import java.util.List;









import org.activiti.engine.impl.util.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qyh.daoImpl.XiangmuDaoImpl;
import com.qyh.entity.Planxm;
import com.qyh.entity.Xiangmu;
import com.qyh.entity.ps;

@Service
public class XiangmuSerImpl {
	@Autowired 
	private XiangmuDaoImpl dao;

	
	public Xiangmu getXiangmuByid(int id){
		return dao.getXiangmuByid(id);
	}
	public List<Xiangmu> getXiangmu(int dwid){
		  List<Xiangmu> list=dao.getXiangmu(dwid);
		  return list;
	  }
	
	public List<Xiangmu> getXiangmuYs(int dwid){
		  List<Xiangmu> list=dao.getXiangmuYs(dwid);
		  return list;
	  }
	  
	  public List<Planxm> getPlanxm(int xmid){
		  return dao.getPlanxm(xmid);
	  }
	  public Xiangmu getXmByProsessid(String prosessid){
		  return dao.getXmByProsessid(prosessid);
	  };
	  public int savexm(Xiangmu x){
		  
		  return dao.savexm(x);
	  }
	  
	  public int saveplanmx(Planxm p){
		  return dao.saveplanxm(p);
	  }
	  
	  public int savexmurl(int xmid,String url,int typeid){
		  return dao.savexmurl(xmid,url,typeid);
	  }
	  
	  public int savezxmx(Planxm zxmx){
		  return dao.savezxmx(zxmx);
	  }
	  public int savecheck(Long num,String url,int zxmxid){
		  return dao.savecheck(num, url, zxmxid);
	  }
	  public int savepay(String url,int zxmxid){
		  return dao.savepay(url, zxmxid);
	  }
	  public List<Planxm> getyszl(int xmid){
		  return dao.getyszl(xmid);
	  }
	  public int delXiangmu(int xmid){
		  return dao.delXiangmu(xmid);
	  }

	  public int savepscon(int uid,int xmid,String pscon,int statu){
		  return dao.savepscon(uid, xmid, pscon,statu);
	  }
	  public int saveyscon(int uid,int xmid,String pscon,int statu){
		  return dao.updateyscon(uid, xmid, pscon,statu);
	  }
	  
	  
	  public int getpscount(int xmid){
		  return dao.getpscount(xmid);
	  }
	  
	  public int getyscount(int xmid){
		  return dao.getyscount(xmid);
	  }
	  
	  public List<Integer> getAllxmidInps(int uid){ //得到某个uid所有正需要评审的xmid
		  return dao.getAllxmidInps(uid);
	  }
	  public List<Integer> getAllxmidInpsTwo(int uid){ //得到某个uid所有已经评审待验收的xmid
		  return dao.getAllxmidInpsTwo(uid);
	  }
	  public List<Integer> getAllxmidInpsThree(int uid){ //得到某个uid所有已经验收的xmid
		  return dao.getAllxmidInpsThree(uid);
	  }
	  
	  public List<Integer> getZjId(int xmid){  //得到所有的审查的专家的id
		  return dao.getZjId(xmid);
	  } 
	  public List<ps> getZjps(int xmid){         //得到ps表里的所有内容 根据xmid
		  return dao.getZjps(xmid);
	  }
	  public int savesjcon(int uid,int xmid,String sjcon){  //存审计内容
		  return dao.savesjcon(uid, xmid, sjcon);
	  }
}
