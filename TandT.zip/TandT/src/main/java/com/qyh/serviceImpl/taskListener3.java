package com.qyh.serviceImpl;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;

public class taskListener3 implements TaskListener{

	@Override
	public void notify(DelegateTask delegateTask) {
		
	}

}
