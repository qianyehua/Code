package com.qyh.serviceImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

import org.activiti.engine.FormService;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.impl.identity.Authentication;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.pvm.PvmTransition;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import org.springframework.web.context.ContextLoader;









import com.qyh.daoImpl.XiangmuDaoImpl;
import com.qyh.entity.Xiangmu;

@Service
public class WorkflowSerImpl {

	@Autowired
	private XiangmuDaoImpl dao;
	@Autowired
	private RepositoryService repositoryService;
	@Autowired
	private RuntimeService runtimeService;
	@Autowired
	private TaskService taskService;
	@Autowired
	private FormService formService;
	@Autowired
	private HistoryService historyService;
	
	
	/**部署流程定义*/
	public void saveNewDeploye() {
		try {
			//2：将File类型的文件转化成ZipInputStream流
//			ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(file));
			String realPath = ContextLoader.getCurrentWebApplicationContext().getServletContext()
                    .getRealPath("/bpmn");
			InputStream inputStreamBpmn =new  FileInputStream(realPath+"/TandI.bpmn");
			InputStream inputStreamPng = new  FileInputStream(realPath+"/TandI.png");
//			System.out.println(inputStreamBpmn);
//			System.out.println(inputStreamPng);
			repositoryService.createDeployment()//创建部署对象
//							.name(filename)//添加部署名称
//							.addZipInputStream(zipInputStream)//
			            .name("TandI")//添加部署的名称
						.addInputStream("TandI.bpmn", inputStreamBpmn)//
						.addInputStream("TandI.png", inputStreamPng)//
							.deploy();//完成部署
		} catch (Exception e) { 
			e.printStackTrace();
		}
	}
	
	/**查询部署对象信息，对应表（act_re_deployment）*/
	public List<Deployment> findDeploymentList() {
		List<Deployment> list = repositoryService.createDeploymentQuery()//创建部署对象查询
							.orderByDeploymenTime().asc()//
							.list();
		return list;
	}
	
	/**查询流程定义的信息，对应表（act_re_procdef）*/
	public List<ProcessDefinition> findProcessDefinitionList() {
		List<ProcessDefinition> list = repositoryService.createProcessDefinitionQuery()//创建流程定义查询
							.orderByProcessDefinitionVersion().asc()//
							.list();
		return list;
	}
	
	/**使用部署对象ID和资源图片名称，获取图片的输入流*/
	public InputStream findImageInputStream(String deploymentId,
			String imageName) {
		return repositoryService.getResourceAsStream(deploymentId, imageName);
	}
	
	/**使用部署对象ID，删除流程定义*/
	public void deleteProcessDefinitionByDeploymentId(String deploymentId) {
		repositoryService.deleteDeployment(deploymentId, true);
	}
	
public void saveStartProcess(int id) {
		
		//1：获取请假单ID，使用请假单ID，查询请假单的对象LeaveBill
//		Long id = workflowBean.getId();
//		LeaveBill leaveBill = leaveBillDao.findLeaveBillById(id);
		Xiangmu xm=dao.getXiangmuByid(id);//!!!!!!!!!!!!
//		int tandi=tandiDao.test(id);
//		System.out.println(tandi);
		//2：更新请假单的请假状态从0变成1（初始录入-->审核中）
//		leaveBill.setState(1);
		
//		tandi.setState("审核中");
//		System.out.println(tandi.getId());
//		3：使用当前对象获取到流程定义的key（对象的名称就是流程定义的key）
//		String key = tandi.getClass().getSimpleName();
		String key="TandI";
//		System.out.println(key);
		/**
		 * 4：从Session中获取当前任务的办理人，使用流程变量设置下一个任务的办理人
			    * inputUser是流程变量的名称，
			    * 获取的办理人是流程变量的值
		 */
		
		Map<String, Object> variables = new HashMap<String,Object>();
		variables.put("InputUser",id+"");//表示惟一用户
//		System.out.println(SessionContext.get().getId()+"");SessionContext.get().getId()+""
		/**
		 * 5：	(1)使用流程变量设置字符串（格式：LeaveBill.id的形式），通过设置，让启动的流程（流程实例）关联业务
   				(2)使用正在执行对象表中的一个字段BUSINESS_KEY（Activiti提供的一个字段），让启动的流程（流程实例）关联业务
		 */
		//格式：LeaveBill.id的形式（使用流程变量）
		String objId = key+"."+xm.getId();
		variables.put("objId", objId);
//		System.out.println(variables);
		//6：使用流程定义的key，启动流程实例，同时设置流程变量，同时向正在执行的执行对象表中的字段BUSINESS_KEY添加业务数据，同时让流程关联业务
			ProcessInstance pi=runtimeService.startProcessInstanceByKey(key,objId,variables);
			xm.setProsessid(pi.getProcessInstanceId());
			xm.setJudge("1");
			dao.updateXm(xm);
		
	}
/**2：使用当前用户名查询正在执行的任务表，获取当前任务的集合List<Task>*/
	public List<Task> findTaskListByName(int id) {
		List<Task> list = taskService.createTaskQuery()//
	//				.taskAssignee(id+"")//指定个人任务查询
				 .taskCandidateUser(id+"")//指定组任务查询
					.orderByTaskCreateTime().asc()//
					.list();
		return list;
	}
	
	public List<Task> findTaskListByName2(int id) {
		List<Task> list = taskService.createTaskQuery()//
				.taskAssignee(id+"")//指定个人任务查询
	//		 .taskCandidateUser(id+"")//指定组任务查询
				.orderByTaskCreateTime().asc()//
				.list();
	return list;
	}
	//查询历史任务
	public List<HistoricTaskInstance> historyTaskList(Long id){
	    List<HistoricTaskInstance> list=historyService.createHistoricTaskInstanceQuery() // 历史任务Service
	            .taskAssignee(id+"") // 指定办理人
	            .finished() // 查询已经完成的任务  
	            .orderByTaskId().asc()//
	            .list();
	    return list;    
	}
	public List<HistoricTaskInstance> historyTaskList2(Long id){
	    List<HistoricTaskInstance> list=historyService.createHistoricTaskInstanceQuery() // 历史任务Service
//	            .taskAssignee(id+"") // 指定办理人
	    		.taskCandidateUser(id+"")
	            .finished() // 查询已经完成的任务  
	            .orderByTaskId().asc()//
	            .list();
	    return list;    
	}
	/**使用任务ID，获取当前任务节点中对应的Form key中的连接的值*/
	public String findTaskFormKeyByTaskId(String taskId) {
		TaskFormData formData = formService.getTaskFormData(taskId);
		//获取Form key的值
		String url = formData.getFormKey();
		return url;
	}

	public int endtask(String prosessid,int id,String result2) {
		// TODO Auto-generated method stub
		Task task= taskService.createTaskQuery()//
				.processInstanceId(prosessid)//使用流程实例ID查询
				.singleResult();
		
		String taskid=task.getId();
		Xiangmu xm=dao.getXiangmuByid(id);
		xm.setState("审核中");
		xm.setJudge(result2);
	//	System.out.println("@@@@@@@@@@@"+taskid);
		try {
			taskService.complete(taskid);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	//	System.out.println("完成");
		/**
		 * 5：在完成任务之后，判断流程是否结束
				如果流程结束了，更新请假单表的状态从1变成2（审核中-->审核完成）
		 */
		ProcessInstance pi = runtimeService.createProcessInstanceQuery()//
						.processInstanceId(prosessid)//使用流程实例ID查询
						.singleResult();
	//	System.out.println("pi"+pi.getId());
		//流程结束了
		if(pi==null){
			System.out.println("结束");
	//		tandi.setState("审核完成");
		}
		dao.updateXm(xm);
		return 1;
	}
	
public int endtaskQYtoZJ(String prosessid,int id,String result2) {
		
	// TODO Auto-generated method stub
			Task task= taskService.createTaskQuery()//
					.processInstanceId(prosessid)//使用流程实例ID查询
					.singleResult();
			
			String taskid=task.getId();
			Xiangmu xm=dao.getXiangmuByid(id);
			xm.setState("审核中");
			xm.setJudge(result2);
		//	System.out.println("@@@@@@@@@@@"+taskid);
			try {
				  Map<String,Object> variables= new HashMap<String,Object>();  
				  List<Integer> idlist=dao.getZjId(id);
						 String a=idlist.get(0).toString().trim();
						 String b=idlist.get(1).toString().trim();
						 String c=idlist.get(2).toString().trim(); 
				  variables.put("users", ""+a+","+b+","+c+"");  
				taskService.complete(taskid,variables);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			/**
			 * 5：在完成任务之后，判断流程是否结束
					如果流程结束了，更新请假单表的状态从1变成2（审核中-->审核完成）
			 */
			ProcessInstance pi = runtimeService.createProcessInstanceQuery()//
							.processInstanceId(prosessid)//使用流程实例ID查询
							.singleResult();
		//	System.out.println("pi"+pi.getId());
			//流程结束了
			if(pi==null){
				System.out.println("结束");
		//		tandi.setState("审核完成");
			}
			dao.updateXm(xm);
			return 1;
		}


	public int endtask2(String prosessid, int id, String resul,String result2) {
		Task task= taskService.createTaskQuery()//
				.processInstanceId(prosessid)//使用流程实例ID查询
				.singleResult();
		
		String taskid=task.getId();
		Xiangmu xm=dao.getXiangmuByid(id);
		int res=Integer.parseInt(resul);
		String result;
		xm.setJudge(result2);
		if(res==0||res==2||res==4){
        	result="通过";
        }
		else if(res==1){
			result="不通过";
            xm.setState("乡镇工办审查不过");
		}
        else{
        	result="不通过";
            xm.setState("经评审项目淘汰");
        }
        
		
		try {
			Map<String, Object> variables = new HashMap<String,Object>();
				variables.put("result",result.trim());
			taskService.complete(taskid,variables);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
//		System.out.println("完成");
		/**
		 * 5：在完成任务之后，判断流程是否结束
   			如果流程结束了，更新请假单表的状态从1变成2（审核中-->审核完成）
		 */
//		System.out.println(prosessid);
		ProcessInstance pi = runtimeService.createProcessInstanceQuery()//
						.processInstanceId(prosessid)//使用流程实例ID查询
						.singleResult();
//		System.out.println("pi"+pi.getId());
		//流程结束了
		if(pi==null){
			System.out.println("结束");
			xm.setState("审核完成");
			xm.setJudge("3");
		}
		dao.updateXm(xm);
		return 1;
	}
	
public int endtask3(String prosessid, Integer id, String result, String result2) {
		
		Task task= taskService.createTaskQuery()//
				.processInstanceId(prosessid)//使用流程实例ID查询
				.singleResult();
		
		String taskid=task.getId();
		Xiangmu xm=dao.getXiangmuByid(id);
		
		int dwid=xm.getDwid();
		int res=Integer.parseInt(result);
		String resul;
		xm.setJudge(result2);
		
		if(res==0||res==2||res==4){
        	resul="通过";
        }
		else if(res==1){
			resul="不通过";
            xm.setState("乡镇工办审查不过");
		}
        else if(res==3){
        	resul="不通过";
            xm.setState("项目淘汰");
        }
        else{
        	resul="不通过";
        	xm.setState("项目淘汰");
        }
		
		try {
			String Dwid=String.valueOf(dwid);
			Map<String, Object> variables = new HashMap<String,Object>();
				variables.put("result",resul.trim());
				variables.put("qyUser",Dwid.trim());
			taskService.complete(taskid,variables);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		ProcessInstance pi = runtimeService.createProcessInstanceQuery()//
				.processInstanceId(prosessid)//使用流程实例ID查询
				.singleResult();
		//System.out.println("pi"+pi.getId());
		//流程结束了
		if(pi==null){
//			System.out.println("结束");
			xm.setState("项目被淘汰");
		}
		dao.updateXm(xm);
		return 1;
	}

	

}
