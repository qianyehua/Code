package com.qyh.serviceImpl;

import java.util.List;

import javax.jms.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.qyh.daoImpl.workFlowDaoImpl;
import com.qyh.entity.User;
public class FirsttaskListener implements TaskListener{
	 
//     workFlowDaoImpl wf=new workFlowDaoImpl();
//	HttpSession session;
	@Override
	public void notify(DelegateTask delegateTask) {
		workFlowDaoImpl wf = SpringContextUtil.getBean("workFlowDaoImpl");
		HttpSession session = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest().getSession();
		int dwid=Integer.parseInt((String) session.getAttribute("dwid"));
//		System.out.println(dwid);
		List<User> list=wf.getXzgbBydwid(dwid);
	
//		System.out.println(list.get(0).getId());
        for(int i=0;i<list.size();i++){
//        	System.out.println("id"+list.get(i).getId());
			delegateTask.addCandidateUser(list.get(i).getId()+"");
		}
		
	}

	
	
}
