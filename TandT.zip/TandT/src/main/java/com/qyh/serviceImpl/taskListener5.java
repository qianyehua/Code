package com.qyh.serviceImpl;

import java.util.List;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qyh.daoImpl.workFlowDaoImpl;
import com.qyh.entity.User;

public class taskListener5 implements TaskListener{
	@Override
	public void notify(DelegateTask delegateTask) {
//IEmployeeService employeeService=(IEmployeeService) SpringContextUtil.getBean("employeeService");
//		
//		List<Employee> list=employeeService.fingsjId();
		workFlowDaoImpl wf = SpringContextUtil.getBean("workFlowDaoImpl");
	List<User> list=wf.getSj();
		
        for(int i=0;i<list.size();i++){
//        	System.out.println("id"+list.size());
			delegateTask.addCandidateUser(list.get(i).getId()+"");
		}
		
	}

}
