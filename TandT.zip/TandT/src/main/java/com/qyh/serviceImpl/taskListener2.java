package com.qyh.serviceImpl;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;

import com.qyh.daoImpl.workFlowDaoImpl;
import com.qyh.entity.User;

public class taskListener2 implements TaskListener{
	@Override
	public void notify(DelegateTask delegateTask) {
		workFlowDaoImpl wf = SpringContextUtil.getBean("workFlowDaoImpl");
		  List<User> list=wf.getZj();
		  System.out.println("专家人数=="+list.size());
			HashSet<Integer> a=new HashSet<Integer>();
			HashSet<Integer> ss=randomSet(list.size()-1,3,a);
			Iterator<Integer> it=ss.iterator();
			while(it.hasNext()){
//			System.out.println("id=="+list.get(it.next()).getId());
//			System.out.println("抽到专家编号2=="+it.next()+"id=="+list.get(it.next()).getId());
				delegateTask.addCandidateUser(list.get(it.next()).getId()+"");//it.next()每用一次自己加一次
			}
			
		
	}
	
	
	 public HashSet<Integer>  randomSet(int max, int n, HashSet<Integer> set) {  
	       if (n > (max+ 1)) {  
	           return null;  
	       }  
	       Random random=new Random();
	       for (int i = 0; i < n; i++) {  
	           // 调用.nextInt()方法  
	           int num =random.nextInt(max+1);
	           System.out.println(num);
	           set.add(num);// 将不同的数存入HashSet中  
	       }  
	       // 如果存入的数小于指定生成的个数，则调用递归再生成剩余个数的随机数，如此循环，直到达到指定大小  
	        while(set.size()< n) {  
	        randomSet(max, n - set.size(), set);// 递归  
	       }  
	       return set;
	   }  

}
