package com.qyh.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qyh.entity.Danwei;
import com.qyh.entity.User;
import com.qyh.mapper.Usermapper;

@Repository
public class LoginDao {
@Autowired 
private Usermapper us;
public List<User> login(String u,String p) {
	 return us.login(u, p);
}
public User getUserlx(int id){
	return us.getUserlx(id);
}
    public Danwei getDanwei(int id){
	return us.getDanwei(id);
}
    public List<User> getUser(){
    	return us.getUser();
    }
    
    public List<Danwei> getAlldanwei(){
    	return us.getAlldanwei();
    }

    public List<Danwei> getAllXiangzheng(){
    	return us.getAllXiangzheng();
    }
    
    public User getUserbyid(int id){
    	return us.getUserbyid(id);
    }


 public int saveUser(User u){
    	return us.saveUser(u);
    } 
    
    public int saveDanwei(Danwei d){
    	return us.saveDanwei(d);
    }
   public int  updateUserDanwei(int dwid,int id){
    	return us.updateUserDanwei(dwid, id);
    }

   public int deleUser(int id){
		return us.deleUser(id);
	}
	
   public int deleDanwei(int id){
		return us.deleDanwei(id);
	}
   
   public int updateUser(User u){
		  return us.updateUser(u);
	  }
	  
	  public int updateDanwei(Danwei d){
		  return us.updateDanwei(d);
	  }
}
