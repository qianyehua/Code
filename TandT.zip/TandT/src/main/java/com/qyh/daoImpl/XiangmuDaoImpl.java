package com.qyh.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qyh.entity.Planxm;
import com.qyh.entity.Xiangmu;
import com.qyh.entity.ps;
import com.qyh.mapper.Xiangmumapper;

@Repository
public class XiangmuDaoImpl {
  @Autowired
  private Xiangmumapper xm;
  public Xiangmu getXiangmuByid(int id){
	  return xm.getXiangmuByid(id);
  };
  
  public List<Xiangmu> getXiangmu(int dwid){
	 return xm.getXiangmu(dwid);
  }
  public List<Xiangmu> getXiangmuYs(int dwid){
		 return xm.getXiangmuYs(dwid);
	  }
  public List<Planxm> getPlanxm(int xmid){
	  return xm.getPlanxm(xmid);
  }
  public Xiangmu getXmByProsessid(String prosessid){
	  return xm.getXmByProsessid(prosessid);
  };
  public int savexm(Xiangmu x){
	  return xm.savexm(x);
  }
  
  public int saveplanxm(Planxm p){
	  return xm.saveplanmx(p);
  }
  
  public int savexmurl(int xmid,String url,int typeid){
	  return xm.savexmurl(xmid,url,typeid);
  }
  
  public int savezxmx(Planxm zxmx){
	  return xm.savezxmx(zxmx);
  }
  public int savecheck(Long num,String url,int zxmxid){
	  return xm.savecheck(num, url, zxmxid);
  }
  public int savepay(String url,int zxmxid){
	  return xm.savepay(url, zxmxid);
  }
  public List<Planxm> getyszl(int xmid){
	  return xm.getyszl(xmid);
  }
  public int delXiangmu(int xmid){
	 return xm.delXiangmu(xmid);  
  }
  
  public int updateXm(Xiangmu x){
	  return xm.updateXm(x);
  }
  public int savepscon(int uid,int xmid,String pscon,int statu){
	  return xm.savepscon(uid, xmid, pscon,statu);
  }
  public int updateyscon(int uid,int xmid,String yscon,int statu){
	  return xm.updateyscon(uid,xmid,yscon,statu);
  }
  public int getpscount(int xmid){
	  return xm.getpscount(xmid);
  }
  public int getyscount(int xmid){
	  return xm.getyscount(xmid);
  }
  
  public List<Integer> getZjId(int xmid){
	  return xm.getZjId(xmid);
  }
  
  public List<Integer> getAllxmidInps(int uid){
	  return xm.getAllxmidInps(uid);
  }
  public List<Integer> getAllxmidInpsTwo(int uid){
	  return xm.getAllxmidInpsTwo(uid);
  }
  public List<Integer> getAllxmidInpsThree(int uid){
	  return xm.getAllxmidInpsThree(uid);
  }
  public List<ps> getZjps(int xmid){
	  return xm.getZjps(xmid);
  }
  public int savesjcon(int uid,int xmid,String sjcon){
	  return xm.savesjcon(uid, xmid, sjcon);
  }
}
