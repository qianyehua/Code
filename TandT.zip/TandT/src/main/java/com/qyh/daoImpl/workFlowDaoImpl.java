package com.qyh.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qyh.entity.User;
import com.qyh.mapper.Workflowmapper;
@Repository
public class workFlowDaoImpl {
	@Autowired
	private Workflowmapper wf;
	
	public List<User> getXzgbBydwid(int dwid){
		return wf.getXzgbBydwid(dwid);
	}
	
	public List<User> getZj(){
		return wf.getZj();
	}
	
	public List<User> getGl(){
		return wf.getGl();
	}
	
	public List<User> getSj(){
		return wf.getSj();
	}
}
