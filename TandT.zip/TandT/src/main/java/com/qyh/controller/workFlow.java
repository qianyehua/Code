package com.qyh.controller;

   import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;









import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;




import org.springframework.web.multipart.MultipartFile;

import com.qyh.entity.Planxm;
import com.qyh.entity.Xiangmu;
import com.qyh.serviceImpl.WorkflowSerImpl;
import com.qyh.serviceImpl.XiangmuSerImpl;


@Controller
public class workFlow {

	@Autowired
	private WorkflowSerImpl workflowService;
	@Autowired
	private XiangmuSerImpl xiangmuSerImpl; 
	/**
	 * 部署管理首页显示
	 * @return
	 */
	@RequestMapping("/deployhome")
	public String deployHome(){
		//1:查询部署对象信息，对应表（act_re_deployment）
//		List<Deployment> depList = workflowService.findDeploymentList();
		//2:查询流程定义的信息，对应表（act_re_procdef）
//		List<ProcessDefinition> pdList = workflowService.findProcessDefinitionList();
		//放置到上下文对象中
		 
		return "gl/workflow";
	}
	
	/**
	 * 发布流程
	 * @return
	 */
	@RequestMapping("newdeploy")
	public String newdeploy(){
		//获取页面传递的值
		//1：获取页面上传递的zip格式的文件，格式是File类型
//		File file = workflowBean.getFile();
//		//文件名称
//		String filename = workflowBean.getFilename();
		//完成部署
		workflowService.saveNewDeploye();
		return "123";  //deployHome
	}
	
	/**
	 * 删除部署信息
	 */
	@RequestMapping("delprosess")
	public String delDeployment(@RequestParam("id") int id){
//		//1：获取部署对象ID
//		String deploymentId = workflowBean.getDeploymentId();
//		//2：使用部署对象ID，删除流程定义
		workflowService.deleteProcessDefinitionByDeploymentId(id+"");
		return "null";
	}
	
	   @RequestMapping("savepscon")
	   public @ResponseBody int savepscon(@RequestParam("uid") int uid,@RequestParam("xmid") int xmid,@RequestParam("pscon") String pscon,@RequestParam("prosessid") String prosessid){
		
		   int i= xiangmuSerImpl.savepscon(uid, xmid, pscon,2);  
		   if(xiangmuSerImpl.getpscount(xmid)==3){
			   workflowService.endtask(prosessid, xmid,"1");
		   }
		   return i;
	   }
	   
	   @RequestMapping("saveyscon")
	   public @ResponseBody int saveyscon(@RequestParam("uid") int uid,@RequestParam("xmid") int xmid,@RequestParam("yscon") String yscon,@RequestParam("prosessid") String prosessid){
		
		   int i= xiangmuSerImpl.saveyscon(uid,xmid,yscon,3);  
		   if(xiangmuSerImpl.getyscount(xmid)==3){
			   workflowService.endtask(prosessid, xmid,"2");
		   }
		   return i;
	   }
	   
	   @RequestMapping("saveyszl")
	   public @ResponseBody int saveyszl(@RequestParam("content") String content,@RequestParam("money") String money,@RequestParam("xmid") int xmid,@RequestParam("num") Long num,@RequestParam("check") MultipartFile checkfile,@RequestParam("pay") MultipartFile payfile,HttpServletRequest request,Planxm zxmx){
		   zxmx.setXmid(xmid);
		   zxmx.setContent(content);
		   zxmx.setMoney(money);
		   int i=xiangmuSerImpl.savezxmx(zxmx);
		   int id=zxmx.getId();
		   String realPath = request.getSession().getServletContext().getRealPath("/imagesFile");
		   // 创建一个文件
	   try{
	       File diskFile = new File(realPath+File.separator
	               + checkfile.getOriginalFilename());
	       // 文件上传,使用FileUtils工具类
	       checkfile.transferTo(diskFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
	   String checkurl="./imagesFile/"+checkfile.getOriginalFilename();
	   xiangmuSerImpl.savecheck(num, checkurl, id);
	   try{
	       File diskFile = new File(realPath+File.separator
	               + payfile.getOriginalFilename());
	       // 文件上传,使用FileUtils工具类
	       payfile.transferTo(diskFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 String payurl="./imagesFile/"+checkfile.getOriginalFilename();
		 int n=xiangmuSerImpl.savepay(payurl, id);
		 
		   return n;
	   }

	@RequestMapping("selectxzgb")
	public @ResponseBody List<Xiangmu> selectxzgb(HttpSession session){
		int uid=Integer.parseInt((String) session.getAttribute("uid"));
//		System.out.println("uid==="+uid);
//		Long uid=(long) 2;
		List<Xiangmu> xm=new ArrayList<Xiangmu>();
		List<Task> list=workflowService.findTaskListByName(uid);//查出该办理人正在进行的任务集合
//		   System.out.println("长度=="+list.size());
			for(int i=0;i<list.size();i++){            //遍历任务集合  放到jsonarray输出
//				System.out.println("prosessid=="+list.get(i).getProcessInstanceId());
                Xiangmu x=new Xiangmu();
				x=xiangmuSerImpl.getXmByProsessid(list.get(i).getProcessInstanceId());
//				System.out.println(x.getId());
				if(x!=null){
	              xm.add(x);
				}
			}
		return xm;
	}
	
	@RequestMapping("selectzjLx")
	public @ResponseBody List<Xiangmu> selectzj(HttpSession session){
		int uid=Integer.parseInt((String) session.getAttribute("uid"));
//		System.out.println("uid==="+uid);
//		Long uid=(long) 2;
		List<Xiangmu> xm=new ArrayList<Xiangmu>();
		List<Task> list=workflowService.findTaskListByName(uid);//查出该办理人正在进行的任务集合
//		   System.out.println("长度=="+list.size());
	     List<Integer> xmidlist=xiangmuSerImpl.getAllxmidInps(uid);
			
			for(int i=0;i<list.size();i++){            //遍历任务集合  放到jsonarray输出
//				System.out.println("prosessid=="+list.get(i).getProcessInstanceId());
                Xiangmu x=new Xiangmu();
				x=xiangmuSerImpl.getXmByProsessid(list.get(i).getProcessInstanceId());
				int m=0;
				for(int n=0;n<xmidlist.size();n++){
//					System.out.println(xmidlist.get(n));
					if(xmidlist.get(n)==x.getId()){
						m=1;
					}
				}
//				System.out.println(x.getId());
				if(m==1){
	              xm.add(x);
				}
			}
		return xm;
	}
	
	@RequestMapping("selectzjPsToYs")
	public @ResponseBody List<Xiangmu> selectzjPsToYs(HttpSession session){
		int uid=Integer.parseInt((String) session.getAttribute("uid"));
//		System.out.println("uid==="+uid);
//		Long uid=(long) 2;
		List<Xiangmu> xm=new ArrayList<Xiangmu>();
		List<Task> list=workflowService.findTaskListByName(uid);//查出该办理人正在进行的任务集合
//		   System.out.println("长度=="+list.size());
	     List<Integer> xmidlist=xiangmuSerImpl.getAllxmidInpsTwo(uid);
			
			for(int i=0;i<list.size();i++){            //遍历任务集合  放到jsonarray输出
//				System.out.println("prosessid=="+list.get(i).getProcessInstanceId());
                Xiangmu x=new Xiangmu();
				x=xiangmuSerImpl.getXmByProsessid(list.get(i).getProcessInstanceId());
				int m=0;
				for(int n=0;n<xmidlist.size();n++){
//					System.out.println(xmidlist.get(n));
					if(xmidlist.get(n)!=x.getId()){
						m=1;
					}
				}
//				System.out.println(x.getId());
				if(m==1){
	              xm.add(x);
				}
			}
		return xm;
	}
	
	@RequestMapping("selectzjYs")
	public @ResponseBody List<Xiangmu> selectzjYs(HttpSession session){
		int uid=Integer.parseInt((String) session.getAttribute("uid"));
//		System.out.println("uid==="+uid);
//		Long uid=(long) 2;
		List<Xiangmu> xm=new ArrayList<Xiangmu>();
		List<Task> list=workflowService.findTaskListByName(uid);//查出该办理人正在进行的任务集合
//		   System.out.println("长度=="+list.size());
	     List<Integer> xmidlist=xiangmuSerImpl.getAllxmidInpsTwo(uid);
			
			for(int i=0;i<list.size();i++){            //遍历任务集合  放到jsonarray输出
//				System.out.println("prosessid=="+list.get(i).getProcessInstanceId());
                Xiangmu x=new Xiangmu();
				x=xiangmuSerImpl.getXmByProsessid(list.get(i).getProcessInstanceId());
				int m=0;
				for(int n=0;n<xmidlist.size();n++){
//					System.out.println(xmidlist.get(n));
					if(xmidlist.get(n)==x.getId()){
						m=1;
					}
				}
//				System.out.println(x.getId());
				if(m==1){
	              xm.add(x);
				}
			}
		return xm;
	}
	
	@RequestMapping("selectzjYsnext")
	public @ResponseBody List<Xiangmu> selectzjYsnext(HttpSession session){
		int uid=Integer.parseInt((String) session.getAttribute("uid"));
//		System.out.println("uid==="+uid);
//		Long uid=(long) 2;
		List<Xiangmu> xm=new ArrayList<Xiangmu>();
	     List<Integer> xmidlist=xiangmuSerImpl.getAllxmidInpsThree(uid);
			
			
				for(int n=0;n<xmidlist.size();n++){
					 Xiangmu x=xiangmuSerImpl.getXiangmuByid(xmidlist.get(n));
					 xm.add(x);	
				}
	              
		return xm;
	}
	
	@RequestMapping("savesj")
	public int savesj(@RequestParam("uid") int uid,@RequestParam("sjcon") String sjcon,@RequestParam("prosessid") String prosessid,@RequestParam("id") int xmid,@RequestParam("result2") String result2){
		xiangmuSerImpl.savesjcon(uid, xmid, sjcon);
		workflowService.endtask(prosessid, xmid, result2);
		return 1;
	}
	
	/**
	 * 提交任务
	 */
	@RequestMapping("Fendtask")
	public int endtask(@RequestParam("prosessid") String prosessid,@RequestParam("id") int id,@RequestParam("result2") String result2){
	    int flag= workflowService.endtask(prosessid, id, result2);
	    
		return flag;
	}
	@RequestMapping("endtask2")
	public @ResponseBody int endtask2(@RequestParam("prosessid") String prosessid,@RequestParam("id") int id,@RequestParam("result") String result,@RequestParam("result2") String result2){
	    int flag= workflowService.endtask2(prosessid, id,result,result2);
	    
		return flag;
	}
	@RequestMapping("endtask3")
	public @ResponseBody int endtask3(@RequestParam("prosessid") String prosessid,@RequestParam("id") int id,@RequestParam("result") String result,@RequestParam("result2") String result2){
		int flag = workflowService.endtask3(prosessid, id, result, result2);
		return flag;
	}
	@RequestMapping("endQytoZj")
	public @ResponseBody int endQytoZj(@RequestParam("prosessid") String prosessid,@RequestParam("id") int id,@RequestParam("result2") String result2){
		int flag = workflowService.endtaskQYtoZJ(prosessid, id, result2);
		return flag;
	}
	@RequestMapping("getQySuccess")
	public @ResponseBody List<Xiangmu> getQySuccess(HttpSession session){
		int uid=Integer.parseInt((String) session.getAttribute("uid"));
		
		return null;
	}
	
}
