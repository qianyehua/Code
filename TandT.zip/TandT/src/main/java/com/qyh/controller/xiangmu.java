package com.qyh.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;












import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.activiti.engine.impl.util.json.JSONArray;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.qyh.entity.Planxm;
import com.qyh.entity.Xiangmu;
import com.qyh.entity.ps;
import com.qyh.serviceImpl.WorkflowSerImpl;
import com.qyh.serviceImpl.XiangmuSerImpl;

@Controller
public class xiangmu {
   @Autowired
   private XiangmuSerImpl ser;
   @Autowired
   private WorkflowSerImpl workflowSer;
   //申报页面 查询 
   @RequestMapping("getXiangmu")
   public @ResponseBody List<Xiangmu> getXiangmu(HttpSession session){
	   int dwid=Integer.parseInt((String) session.getAttribute("dwid"));
	   return ser.getXiangmu(dwid);
   }
   //申报页面 验收
   @RequestMapping("getXiangmuYs")
   public @ResponseBody List<Xiangmu> getXiangmuYs(HttpSession session){
	   int dwid = Integer.parseInt((String) session.getAttribute("dwid"));
	   return ser.getXiangmuYs(dwid);
   }
   //详情页面 获取计划内容
   @RequestMapping("getPlanxm")
   public @ResponseBody List<Planxm> getPlanxm(@RequestParam(value="xmid", required = false) Integer xmid){
//	   System.out.println(xmid);
	   return ser.getPlanxm(xmid);
   }
 //详情页面 获取专家评审内容
   @RequestMapping("getPs")
   public @ResponseBody List<ps> getPs(@RequestParam(value="xmid", required = false) Integer xmid){
//	   System.out.println(xmid);
	   return ser.getZjps(xmid);
   }

   //申报 项目
   @RequestMapping("savexm")
   public @ResponseBody int savexm(@RequestBody Xiangmu x){
	   x.setState("已申报");
	   ser.savexm(x);
	   workflowSer.saveStartProcess(x.getId());//启动项目
	   return x.getId();
   }
   
   @RequestMapping("saveplanxm")
   public @ResponseBody int saveplanmx(@RequestBody Planxm pxm){
//	   for(Planxm pxm:list ){
	   if(pxm.getMoney()!=null){
		   ser.saveplanmx(pxm);
	   }
//	   }
	   return 1;
   }
   
   @RequestMapping("savexmurl")
   public String savexmurl(@RequestParam("xmid") int xmid,@RequestParam("file") MultipartFile file,Xiangmu x,HttpServletRequest request){
	   
	 try {
	   String realPath = request.getSession().getServletContext().getRealPath("/imagesFile");
//       System.out.println(realPath);
       // 创建一个文件
       File diskFile = new File(realPath+File.separator
               + file.getOriginalFilename());
       // 文件上传,使用FileUtils工具类
       file.transferTo(diskFile);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 String url="./imagesFile/"+file.getOriginalFilename();
	 ser.savexmurl(xmid,url,1);
	   return "qy/qysb";
   }
   
   @RequestMapping("delXiangmu")
   public @ResponseBody int delXiangmu(@RequestParam("xmid") int xmid){
	   return ser.delXiangmu(xmid);
   }
 
   //得到 所有的验收资料
   @RequestMapping("getyszl")
   public @ResponseBody List<Planxm> getyszl(@RequestParam("xmid") int xmid){
	   return ser.getyszl(xmid);
   }


}



//var editedinfo={
//	       "userid":idd,
//	     "studentid":$("#studentid11").val(),
//       "stuname":$("#stuname11").val(),
// 		"major":$("#major11").val(),
// 	    "level":$("#level11").val(),
// 	    "season":$("#season11").val(),
// 	    "remark":$("#remark11").val(),
// 		"schoolroll":$("#schoolroll11").val(),
//  		"tel":$("#tel11").val(),
//  		"password":$("#password11").val(),
//  		"email":$("#email11").val()
//};
//$.ajax({
//   type:"Post",
//   url:"ManagerStudentInfo/editStudent.spring",
//   async:false,
//   data:JSON.stringify(editedinfo),
//   contentType:'application/json',
//   dataType:"json", 
//    success:function(flag)
