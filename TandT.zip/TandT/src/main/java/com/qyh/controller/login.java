package com.qyh.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.activiti.engine.impl.util.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qyh.entity.Danwei;
import com.qyh.entity.User;
import com.qyh.serviceImpl.LoginSer;

@Controller
public class login {
@Autowired 
private LoginSer ser;
	@RequestMapping("login")
	public String login(@RequestParam(value="username") String username,@RequestParam(value="password") String password,HttpSession httpsession){
		httpsession.setAttribute("uname", username);
		httpsession.setAttribute("dwid", ser.getUser(username, password).getDwid()+"");
		httpsession.setAttribute("uid",ser.getUser(username, password).getId()+"");
	       return ser.Login(username, password);
	}
	
	
  @RequestMapping("getdanwei")  //根据用户对应的单位 获取单位信息 包括所属乡镇 单位类型
  public @ResponseBody Danwei getdanwei(@RequestParam(value="id") int id){

	  return ser.getDanwei(id);
	  
  }
  
  @RequestMapping("getAlluser")  //获取所有用户信息 包括用户类型
  public @ResponseBody List<User> getuser(){
	  return ser.getUser2();
  }
  
  @RequestMapping("getAlldanwei")  //获取所有用户信息 包括用户类型
  public @ResponseBody List<Danwei> getAlldanwei(){
	  return ser.getAlDanwei();
  }
  
  @RequestMapping("getUserbyid")
  public @ResponseBody User getUserbyid(@RequestParam(value="id")int id){
	 	return ser.getUserbyid(id);
	 }

@RequestMapping("getDanweiChoo")  //下拉框里显示可选的乡镇
  public @ResponseBody List<Map> getDanweiChoo(){
	  return ser.getDanweiChoose();
  }


@RequestMapping("saveUser")   //增加用户 返回值为1 插入成功 ，返回0 插入失败
  public @ResponseBody int saveUser(@RequestBody User u){
//    System.out.println("#########");
//	System.out.println(u.getPassword());
	  return ser.saveUser(u);
  }
  
  @RequestMapping("saveDanwei")   //增加单位 返回值为1 插入成功 ，返回0 插入失败
  public @ResponseBody int saveDanwei(@RequestBody Danwei d){
	  return ser.saveDanwei(d);
  }
 @RequestMapping("updateUserDanwei") //保存用户对应单位的设置
  public @ResponseBody int updateUserDanwei(@RequestParam(value="dwid") int dwid,@RequestParam(value="id") int id){
	
	 return ser.updateUserDanwei(dwid, id);
  }
@RequestMapping("deleUser")  //删除用户
  public @ResponseBody int deleUser(@RequestParam(value="id")int id){
		return ser.deleUser(id);
	}
  
  @RequestMapping("deleDanwei") //删除单位 并删除该单位所有用户
	public @ResponseBody int deleDanwei(@RequestParam(value="id") int id){
		return ser.deleDanwei(id);
	}
  @RequestMapping("updateUser")  //更改用户信息 编辑
  public @ResponseBody int updateUser(@RequestBody User u){
	return ser.updateUser(u);
}

@RequestMapping("updateDanwei")  //更改单位信息 编辑
  public @ResponseBody int pdateDanwei(@RequestBody Danwei d){
	return ser.updateDanweu(d);
}

}
