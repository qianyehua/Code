package com.qyh.mapper;

import java.util.List;

import com.qyh.entity.Danwei;
import com.qyh.entity.User;

public interface Usermapper {

	
	
	List<User> login(String u,String p);
	User getUserlx(int id);
	Danwei getDanwei(int id);
	
	
	List<User> getUser();
	List<Danwei> getAlldanwei();
	List<Danwei> getAllXiangzheng();
	User getUserbyid(int id);//根据用户id 得到用户详细信息 包括类型所属单位
	int saveUser(User u);
	int saveDanwei(Danwei d);
	int updateUserDanwei(int dwid,int id);
	int deleUser(int id);
	int deleDanwei(int id);
	
	int updateUser(User u);
	int updateDanwei(Danwei d);
}
