package com.qyh.mapper;

import java.util.List;

import com.qyh.entity.User;

public interface Workflowmapper {
	List<User> getXzgbBydwid(int dwid);
	
	List<User> getZj();
	
	List<User> getGl();
	
	List<User> getSj();
}
