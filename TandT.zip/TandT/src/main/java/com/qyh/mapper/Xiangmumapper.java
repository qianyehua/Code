package com.qyh.mapper;

import java.util.List;

import com.qyh.entity.Planxm;
import com.qyh.entity.Xiangmu;
import com.qyh.entity.ps;

public interface Xiangmumapper {
  Xiangmu getXiangmuByid(int id);
  List<Xiangmu> getXiangmu(int dwid);
  List<Xiangmu> getXiangmuYs(int dwid);
  List<Planxm> getPlanxm(int xmid);
  Xiangmu getXmByProsessid(String prosessid);
  int savexm(Xiangmu x);
  int saveplanmx(Planxm p);
  int savexmurl(int xmid,String xmurl,int typeid);
  int savezxmx(Planxm p);
  int savecheck(Long num,String url,int zxmxid);
  int savepay(String url,int zxmxid);
  List<Planxm> getyszl(int xmid);
  int delXiangmu(int xmid);
  int updateXm(Xiangmu xm);
  int savepscon(int uid,int xmid,String pscon,int statu);
  int updateyscon(int uid,int xmid,String ysscon,int statu);
  int getpscount(int xmid);
  int getyscount(int xmid);
  List<Integer> getAllxmidInps(int uid); //查专家正在评审的项目id
  List<Integer> getAllxmidInpsTwo(int uid); //查专家已经评审了的正在验收项目id
  List<Integer> getAllxmidInpsThree(int uid); //查专家已经验收了的项目id
  List<Integer> getZjId(int xmid);
  List<ps> getZjps(int xmid);
  int savesjcon(int uid,int xmid,String sjcon);
}
