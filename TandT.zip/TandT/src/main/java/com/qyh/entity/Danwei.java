package com.qyh.entity;

public class Danwei {
	private int id;
	   private String name;
	   private String address;
	   private String people;
	   private String phone;
	   private String town;
	   private String lx;
	   private int townid;
	   private int dwlxid;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPeople() {
		return people;
	}
	public void setPeople(String people) {
		this.people = people;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getLx() {
		return lx;
	}
	public void setLx(String lx) {
		this.lx = lx;
	}
	public int getTownid() {
		return townid;
	}
	public void setTownid(int townid) {
		this.townid = townid;
	}
	public int getDwlxid() {
		return dwlxid;
	}
	public void setDwlxid(int dwlxid) {
		this.dwlxid = dwlxid;
	}
	
}
