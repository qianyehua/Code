package com.qyh.entity;

public enum Enumflaf {
  success(0,"成功"),
  fail(1,"失败"),
  ing(2,"进行中");
  
  private Enumflaf(int value, String dec) {
	this.value = value;
	this.dec = dec;
}
private int value;
  private String dec;
	public int getValue() {
		return value;
	}
	public String getDec() {
		return dec;
	}
  
  
}
