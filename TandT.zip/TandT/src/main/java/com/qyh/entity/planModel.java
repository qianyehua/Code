package com.qyh.entity;

import java.util.List;

public class planModel {

	private List<Planxm> list;

	public List<Planxm> getList() {
		return list;
	}

	public void setList(List<Planxm> list) {
		this.list = list;
	}
	
}
