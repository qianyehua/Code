package com.qyh.entity;

public class ps {
	private int id;
	private int xmid;
	private int uid;
	private String zj; //专家名称
	private String pscon;
	private String yscon;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getXmid() {
		return xmid;
	}
	public void setXmid(int xmid) {
		this.xmid = xmid;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getZj() {
		return zj;
	}
	public void setZj(String zj) {
		this.zj = zj;
	}
	public String getPscon() {
		return pscon;
	}
	public void setPscon(String pscon) {
		this.pscon = pscon;
	}
	public String getYscon() {
		return yscon;
	}
	public void setYscon(String yscon) {
		this.yscon = yscon;
	}
	
}
