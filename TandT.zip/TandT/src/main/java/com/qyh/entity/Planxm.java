package com.qyh.entity;

public class Planxm {
  private int id;
  private String content;
  private String money;
  private int xmid;
  private long num;
  private String checkurl;
  private String payurl;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
public String getMoney() {
	return money;
}
public void setMoney(String money) {
	this.money = money;
}
public int getXmid() {
	return xmid;
}
public void setXmid(int xmid) {
	this.xmid = xmid;
}
public long getNum() {
	return num;
}
public void setNum(long num) {
	this.num = num;
}
public String getCheckurl() {
	return checkurl;
}
public void setCheckurl(String checkurl) {
	this.checkurl = checkurl;
}
public String getPayurl() {
	return payurl;
}
public void setPayurl(String payurl) {
	this.payurl = payurl;
}
  
}
