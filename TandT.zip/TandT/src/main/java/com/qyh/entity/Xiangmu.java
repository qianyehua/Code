package com.qyh.entity;

public class Xiangmu {
  private int id;
  private String xmname;
  private String xmcontent;
  private String hykids;
  private String xmsdate;
  private String xmedate;
  private String xmurl;
  private int dwid;
  private String danwei;
  private String state; 
  private String prosessid;
  private String judge;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getXmname() {
	return xmname;
}
public void setXmname(String xmname) {
	this.xmname = xmname;
}
public String getXmcontent() {
	return xmcontent;
}
public void setXmcontent(String xmcontent) {
	this.xmcontent = xmcontent;
}
public String getHykids() {
	return hykids;
}
public void setHykids(String hykids) {
	this.hykids = hykids;
}

public String getXmsdate() {
	return xmsdate;
}
public void setXmsdate(String xmsdate) {
	this.xmsdate = xmsdate;
}
public String getXmedate() {
	return xmedate;
}
public void setXmedate(String xmedate) {
	this.xmedate = xmedate;
}
public int getDwid() {
	return dwid;
}
public void setDwid(int dwid) {
	this.dwid = dwid;
}
public String getXmurl() {
	return xmurl;
}
public void setXmurl(String xmurl) {
	this.xmurl = xmurl;
}

public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getProsessid() {
	return prosessid;
}
public void setProsessid(String prosessid) {
	this.prosessid = prosessid;
}
public String getJudge() {
	return judge;
}
public void setJudge(String judge) {
	this.judge = judge;
}
public String getDanwei() {
	return danwei;
}
public void setDanwei(String danwei) {
	this.danwei = danwei;
}

  
}
