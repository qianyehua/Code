package com.qyh.entity;

public class User {
   private int id;
   private String username;
   private String password;
   private int dwid;
   private int lxid;
   private String role;
   private String name;
   
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}


public int getDwid() {
	return dwid;
}
public void setDwid(int dwid) {
	this.dwid = dwid;
}
public int getLxid() {
	return lxid;
}
public void setLxid(int lxid) {
	this.lxid = lxid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}


   
}
