$(document).ready(function(){
$(".btn").click(function(){
//	var s={"kkl":$("#liuyan").val()}
	
	$.ajax({
		type:"post",
		url:"servlet/liuyanServlet",
		data:{"liuyan":$("#liuyan").val()},
		dataType:"json",
		success:function(){
			alert("留言成功!")
			$("#liuyan").val("");
		}
	})
})
})