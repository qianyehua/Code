$.ajax({
	type:"post",
	url:"servlet/biaotiServlet",
	dataType:"json",
	success:function(array){
		for(var i=0;i<array.length;i++){
		  $(".kind ul").append("<li class='bdrn'> <a href="+array[i].url+" >"+array[i].title+"</a></li>")
		}
      
	}
	
})