$.ajax({
	type:"post",
	url:"servlet/biaoti3Servlet",
	dataType:"json",
	success:function(array){
		for(var i=0;i<array.length;i++){
		  $(".kind ul").append("<li class='bdrn'> <a href='Web/Jsp/product.jsp?id="+array[i].categoryid+"'' >"+array[i].title+"</a></li>")
		}
      
	}
	
})