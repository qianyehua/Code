
$.ajax({
	type:"post",
	url:"servlet/daohangServlet",
	dataType:"json",
	success:function(array){
		for(var i=0;i<array.length;i++){
		$(".nav").append("<li><a href="+array[i].url+">"+array[i].title+"</a></li>");
		}
	
	
	}
})