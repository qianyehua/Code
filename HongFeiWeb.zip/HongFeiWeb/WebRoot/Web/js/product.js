$.ajax({
	type:"post",
	data:{"page":0},
	url:"servlet/productHome",
	dataType:"json",
		success:function(array){
			for( var i=0;i<6;i++){
			$(".imgbox").append("<li><a href='Web/Jsp/allproduct.jsp?id="+array[i].id+"'''><img src="+array[i].imgurl+" /></a><a href='' class='show'>"+array[i].name+"</a></li>");}
			
//			document.getElementById("imgp1").src=array[0].imgurl;
//			document.getElementById("imgp2").src=array[1].imgurl;
//			document.getElementById("imgp3").src=array[2].imgurl;
//			document.getElementById("imgp4").src=array[3].imgurl;
//			document.getElementById("imgp5").src=array[4].imgurl;
//			document.getElementById("imgp6").src=array[5].imgurl;
		}
	
})