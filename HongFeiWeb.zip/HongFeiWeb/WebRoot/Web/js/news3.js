$.ajax({
	type:"post",
	url:"servlet/news3Servlet",
	dataType:"json",
	success:function(array){
		for(var i=0;i<array.length;i++){
		$("#new_p").append("<li><span>"+array[i].time+"</span><a href='' title=''>"+array[i].title+"</a></li>")
		}
   	  
		for(var i=0;i<array.length;i++){
			$(".news_list").append("<dl><h3><a  href='sjjmy.html' title="+array[i].title+" target='_blank'>"+array[i].title+"</a></h3><dt><a href='sjjmy.html' title="+array[i].title+" target='_blank'><img src="+array[i].imgurl+" alt="+array[i].title+" width='150'></a></dt><dd class='shortdd'><a href=''>"+array[i].content+"</a><span>"+array[i].time+"</span></dd></dl>");
		}

	}
	
})