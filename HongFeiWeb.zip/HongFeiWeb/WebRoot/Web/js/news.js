$.ajax({
	type:"post",
	data:{"page":0},
	url:"servlet/newsHome",
	dataType:"json",
	success:function(array){
		for(var i=0;i<array.length;i++){
			 var a=format(array[i].time);

		
		$("#new_p").append("<li><span>"+a+"</span><a href='Web/Jsp/allnews.jsp?id="+array[i].newsid+"'' title=''>"+array[i].title+"</a></li>")
		}
   	  
//		for(var i=0;i<array.length;i++){
//			$(".news_list").append("<dl><h3><a  href='sjjmy.html' title="+array[i].title+" target='_blank'>"+array[i].title+"</a></h3><dt><a href='sjjmy.html' title="+array[i].title+" target='_blank'><img src="+array[i].imgurl+" alt="+array[i].title+" width='150'></a></dt><dd class='shortdd'><a href=''>"+array[i].content+"</a><span>"+array[i].time+"</span></dd></dl>");
//		}
//		<dl>
//        <h3><a href="sjjmy.html" title="中国兴起VR热潮 市场规模将达8.6亿" target="_blank">中国兴起VR热潮 市场规模将达8.6亿</a></h3>
//        <dt><a href="sjjmy.html" title="中国兴起VR热潮 市场规模将达8.6亿" target="_blank"><img src="images/photo1.png" alt="中国兴起VR热潮 市场规模将达8.6亿" width="150"></a></dt>              
//        <dd class="shortdd"><a href="">　　为进一步贯彻落实“中国制造2025”、“互联网＋”等国家战略，促进全市智能制造资源共享，推进产业转型升级，1月17日，由市经信委倡议，宁波均胜集团、中科院宁波材料所等16家制造企业及科研机构联合发起的宁波市...</a><span>发布时间：2016-03-22 14:12</span></dd>
//      </dl>
	
	}
	
	
})
     function format(a2){  
	   var date=new Date(a2);  
	   var y = date.getFullYear();
	   var m = date.getMonth()+1;
       var d = date.getDate();
	   return y+"-"+m+"-"+d;
	} 

   



