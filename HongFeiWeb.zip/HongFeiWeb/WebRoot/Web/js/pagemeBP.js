 
/* ��̬д������ */
 function view(array){
       $(".imgbox1").html(" ");
    for(var i = 0; i < array.length;i++) {
    	
    	$(".imgbox1").append("<li><a href='Web/Jsp/allproduct.jsp?id="+array[i].id+"'''><img src="+array[i].imgurl+" /></a><a href='Web/Jsp/allproduct.jsp?id="+array[i].id+"''' class='show'>"+array[i].name+"</a></li>");
    }
    
 }
  /* ajax ����������� */
 function sendAjax(page,size){
	
//    var url = '';
//    view(data.data[page-1].con);
    $.ajax({  
        url:'servlet/BproductServlet',  
        type:'post',  
         data:{"page":page},  
        dataType: 'json',
        success: function(array) {
            if(array){
                view(array)
            }
        }
    });
 }