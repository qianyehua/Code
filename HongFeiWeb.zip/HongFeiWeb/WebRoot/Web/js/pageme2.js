 
/* ��̬д������ */
 function view(array){
       $(".news_list").html(" ");
    for(var i = 0; i < array.length;i++) {
    	$(".news_list").append("<dl><h3><a  href='Web/Jsp/allnews.jsp?id="+array[i].newsid+"''' title="+array[i].title+" >"+array[i].title+"</a></h3><dt><a href='Web/Jsp/allnews.jsp?id="+array[i].newsid+"''' title="+array[i].title+" ><img src="+array[i].imgurl+" alt="+array[i].title+" width='150'></a></dt><dd class='shortdd'><div id='aa'><a method='post' href='Web/Jsp/allnews.jsp?id="+array[i].newsid+"'''>"+array[i].content+"</a></div><span>"+array[i].time+"</span></dd></dl>");
    }
    
 }
  /* ajax ����������� */
 function sendAjax(page,size){
	
//    var url = '';
//    view(data.data[page-1].con);
    $.ajax({  
        url:'servlet/new2Servlet',  
        type:'post',  
         data:{"page":page},  
        dataType: 'json',
        success: function(array) {
            if(array){
                view(array)
            }
        }
    });
 }