	$.ajax({
		type:"post",
		url:"servlet/homeimgServlet",
		dataType:"json",
		success:function(array){
			for(var i=0;i<array.length;i++){
				
			$(".picmove").append("<li><img src="+array[i].imgurl+"></li>")
			}
			 jQuery(".banner").slide({ titCell:".num li", mainCell:".picmove",effect:"fold", autoPlay:true,trigger:"click",
			        startFun:function(i){
			            jQuery(".banner li").eq(i).animate({"bottom":0}).siblings().animate({"bottom":-55});
			            }
			          });
		}
	})


 $.ajax({
	 type:"post",
	 url:"servlet/aboutServlet",
     dataType:"json",
     success:function(array2){
    	//公司简介
    	 $("#dfds").append("<a href=''><img src="+array2[0].imgurl+" style='padding:5px 8px 0 8px;float:left'></a>");
    	 $("#dfds").append(array2[0].Content);
    	 //公司简介
    	 $("#about1").append("<img src="+array2[0].imgurl+" width='210px' height='130px'>");
    	 $("#about1").append(array2[0].Content);
    	//资质证书
    	 $("#content_zzzs").append("<img src="+array2[1].imgurl+" width='160px' height='200px'>");
    	 $("#content_zzzs").append(array2[1].Content);
    	 //企业文化
    	 $("#culture").append("<img src="+array2[2].imgurl+" width='210px' height='130px'>");
    	 $("#culture").append(array2[2].Content);
    	 
    	 //联系我们
    	
    	 
     }
	
 })
     $.ajax({
		type:"post",
        url:"servlet/lxwmServlet",
        dataType:"json",
        success:function(array){
        	 //联系我们
        	for(var i=0;i<array.length;i++){
       	 $("#table_p").append("<tr><th colspan='2' align='left' style='padding-left:10px;'>"+array[i].name+"</th></tr>");
       	 $("#table_p").append("<tr><td style='width:30px;padding-left:10px'>地址:</td><td style='width:200px'>"+array[i].address+"</td></tr>");
       	 $("#table_p").append("<tr><td style='width:30px;padding-left:10px'>电话:</td><td>"+array[i].tel+"</td></tr>");
       	 $("#table_p").append("<tr><td style='width:30px;padding-left:10px'>邮箱:</td><td>"+array[i].email+"</td></tr>");
       	 $("#table_p").append("<tr><td style='width:30px;padding-left:10px'>传真:</td><td>"+array[i].fax+"</td></tr>");
       	 $("#table_p").append("<tr><td style='width:30px;padding-left:10px'>联系:</td><td>"+array[i].per+"</td></tr>");
       	 
       	 
       	 $("#lxwm").append("<img src="+array[i].imageurl+" width='200px' height='160px'>");
       	 
       //footer
    	 $(".footer p").append("</br>"+array[i].name+"");
    	 $(".footer p").append("</br>"+array[i].address+"");
        }
        }	 
		 
	 })
	 //友情链接
	 $.ajax({
		 type:"post",
		 url:"servlet/friendlinkServlet",
		 dataType:"json",
		 success:function(array){
			 for(var i=0;i<array.length;i++){
			 $("#4399").append("<li><img src="+array[i].imgurl+" class='smlogo'><a target='_blank' href="+array[i].href+">"+array[i].name+"</a></li>");
			 }
		}
		 
	 })
  