$(document).ready(function(){
$.ajax({
	type:"post",
	url:"servlet/allproductServlet",
	data:{"id":$("#qyh").text()},
	dataType:"json",
	success:function(object){
		$("#all").append("<div><h1 style='font-size:40px'>"+object.name+"</h1><img src='"+object.imgurl+"' style='padding:5px 8px 0 8px;float:left' ><p style='font-size:15px'>"+object.memo+"</p></div><p style='color:#CFCFCF'>"+object.time+"</p>")
	}
})
})