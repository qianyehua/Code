package com.HongFei.Tool;

import java.lang.reflect.Array;
import java.util.Arrays;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.HongFei.Service.aboutService;
import com.HongFei.Service.biaotiService;
import com.HongFei.Service.daohangService;
import com.HongFei.Service.newService;
import com.HongFei.Service.newpageService;
import com.HongFei.Service.submitliuyanService;

public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String[] a=new String[]{"azsdsd","zda","bs"};
		Arrays.sort(a);
       for(int i=0;i<a.length;i++){
		System.out.println(a[i]);
       }
	}

	

}
