package com.HongFei.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.HongFei.Model.about;
import com.HongFei.Model.lxwm;
import com.HongFei.Service.aboutService;

public class lxwmServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

//		servlet/lxwmServlet
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		JSONArray array=new JSONArray();
		JSONObject object2=null;
		
		ArrayList<lxwm> list;
		aboutService about=new aboutService();
		try {
			
		
	
		list=(ArrayList<lxwm>) about.about2();
		for(int i=0;i<list.size();i++){
			object2=new JSONObject();
			
			object2.put("name", list.get(i).getName());
			object2.put("address", list.get(i).getAddress());
			object2.put("tel", list.get(i).getTel());
			object2.put("email", list.get(i).getEmail());
			object2.put("fax", list.get(i).getFax());
			object2.put("per", list.get(i).getPerson());
			object2.put("imageurl", list.get(i).getImgurl());
			array.add(object2);
			
		}
		
		} catch (Exception e) {
			// TODO: handle exception
		}			
//		System.out.println("+++++++++++++++");
//		System.out.println(array2);
		PrintWriter out = response.getWriter();
		out.print(array);
		out.flush();
		out.close();
	}

}
