package com.HongFei.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.HongFei.Model.product;
import com.HongFei.Service.productService;

public class productHome extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
///servlet/productHome
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		JSONArray array=new JSONArray();
		JSONObject object=null;
		ArrayList<product> list;
		productService product=new productService();
		try {
			
			list=(ArrayList<product>) product.productHome();
		
		for(int i=0;i<list.size();i++){
			object=new JSONObject();
			object.put("id", list.get(i).getProductid());
			object.put("name", list.get(i).getName());
			object.put("imgurl", list.get(i).getImgurl());
			object.put("time", list.get(i).getTime());
			
			array.add(object);
		}
		
		} catch (Exception e) {
			// TODO: handle exception
		}			
		
		PrintWriter out = response.getWriter();
		out.print(array);
		out.flush();
		out.close();
	}

}
