package com.HongFei.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.HongFei.Model.news;
import com.HongFei.Model.product;
import com.HongFei.Service.allnewsService;
import com.HongFei.Service.allproductService;

public class allproductServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

//		servlet/allproductServlet
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		String id=request.getParameter("id");
		int productid=Integer.parseInt(id);		
		
		JSONObject object=null;
		ArrayList<product> list;
		allproductService allproduct=new allproductService();
		try {
		list=(ArrayList<product>) allproduct.productall(productid);
		
		for(int i=0;i<list.size();i++){
			object=new JSONObject();
		    
			object.put("name",list.get(i).getName());
			object.put("memo",list.get(i).getMemo());
			object.put("imgurl", list.get(i).getImgurl());
			object.put("time", list.get(i).getTime());
			
		}
		
		} catch (Exception e) {
			// TODO: handle exception
		}			
		
		
		
		PrintWriter out = response.getWriter();
		out.print(object);
		out.flush();
		out.close();
	}

}
