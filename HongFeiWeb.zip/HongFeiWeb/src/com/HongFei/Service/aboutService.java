package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import com.HongFei.Model.about;
import com.HongFei.Model.lxwm;
import com.HongFei.Tool.DBConn;

public class aboutService {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	
	public 	List<about> about(){
		List<about> list=new ArrayList<about>();
	
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_CompanyInfo");
			rs=st.executeQuery();
			while(rs.next()){
				about a=new about();
				a.setContent(rs.getString("Content"));
				a.setImageurl(rs.getString("ImgUrl"));
				a.setImgname(rs.getString("ImgName"));
				
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
		
	}

	
	public 	List<lxwm> about2(){
		List<lxwm> list=new ArrayList<lxwm>();
	
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_ContactUs");
			rs=st.executeQuery();
			while(rs.next()){
				lxwm a=new lxwm();
				a.setName(rs.getString("name"));
				a.setAddress(rs.getString("Address"));
				a.setTel(rs.getString("Tel"));
				a.setEmail(rs.getString("Email"));
				a.setFax(rs.getString("Fax"));
				a.setPerson(rs.getString("Person"));
				a.setImgurl(rs.getString("ImgUrl"));
				
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
		
	}
}
