package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.HongFei.Model.about;
import com.HongFei.Model.news;
import com.HongFei.Tool.DBConn;

public class allnewsService {
	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	
	public 	List<news> newsall(int newsid){
		List<news> list=new ArrayList<news>();
	
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_News where NewsId=?");
			st.setInt(1,newsid);
			rs=st.executeQuery();
			while(rs.next()){
				news a=new news();
				a.setTitle(rs.getString("Title"));
				a.setContent(rs.getString("Content"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setTime(rs.getString("Time"));
				
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
		
	}
	
}
