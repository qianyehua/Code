package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.HongFei.Model.friendlink;
import com.HongFei.Model.news;
import com.HongFei.Tool.DBConn;

public class friendlinkService {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	
	public 	List<friendlink> friend(){
		List<friendlink> list=new ArrayList<friendlink>();
	
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_FriendLink where InHomePage=1");
			rs=st.executeQuery();
			while(rs.next()){
				friendlink a=new friendlink();
				a.setLinkId(rs.getInt("LinkId"));
				a.setName(rs.getString("Name"));
				a.setImgUrl(rs.getString("ImgUrl"));
				a.setHref(rs.getString("Href"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
		
	}

}
