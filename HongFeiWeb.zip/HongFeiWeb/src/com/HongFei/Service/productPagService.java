package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.HongFei.Tool.DBConn;

public class productPagService {

	int i;
	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	public int page(int id){
		    
		conn=DBConn.getCon();
		try {
			
			st=conn.prepareStatement("select * from T_Product where CategoryId=?");
			st.setInt(1, id);
		    rs =st.executeQuery();
		   
		    while(rs.next()){
		    	i++;
		    }
			return i;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
	     return 0;
	}
	
	public int page2(){
	    
		conn=DBConn.getCon();
		try {
			
			st=conn.prepareStatement("select * from T_Product");
		    rs =st.executeQuery();
		   
		    while(rs.next()){
		    	i++;
		    }
			return i;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
	     return 0;
	}

	
	public int page3(){
	    
		conn=DBConn.getCon();
		try {
			
			st=conn.prepareStatement("select * from T_Product where CategoryId=23");
		    rs =st.executeQuery();
		   
		    while(rs.next()){
		    	i++;
		    }
			return i;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
	     return 0;
	}
}
