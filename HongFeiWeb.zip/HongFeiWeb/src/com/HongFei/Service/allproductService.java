package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.HongFei.Model.news;
import com.HongFei.Model.product;
import com.HongFei.Tool.DBConn;

public class allproductService {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	
	public 	List<product> productall(int productid){
		List<product> list=new ArrayList<product>();
	
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_Product where ProductId=?");
			st.setInt(1,productid);
			rs=st.executeQuery();
			while(rs.next()){
				product a=new product();
				a.setProductid(rs.getInt("ProductId"));
				a.setName(rs.getString("Name"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setMemo(rs.getString("Memo"));
				a.setTime(rs.getString("Time"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
		
	}

}
