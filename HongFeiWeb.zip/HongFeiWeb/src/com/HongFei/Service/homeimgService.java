package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.HongFei.Model.homeimg;
import com.HongFei.Model.product;
import com.HongFei.Tool.DBConn;

public class homeimgService {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	public List<homeimg> img(){
		List<homeimg> list=new ArrayList<homeimg>();
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_HomeImg");
			rs=st.executeQuery();
			while(rs.next()){
				homeimg a=new homeimg();
				a.setImgurl(rs.getString("ImgUrl"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
	}

}
