package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.HongFei.Model.daohang;
import com.HongFei.Tool.DBConn;

public class daohangService {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	public List<daohang> cate(){
		List<daohang> list=new ArrayList<daohang>();
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_Category where InTitle=1");
			rs=st.executeQuery();
			while(rs.next()){
				daohang d=new daohang();
				d.setName(rs.getString("Name"));
				d.setUrl(rs.getString("url"));
				d.setCategoryid(rs.getInt("CategoryId"));
				d.setParentid(rs.getInt("ParentId"));
				list.add(d);
			}	
                return list;			    
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		return null;
		
	}

}
