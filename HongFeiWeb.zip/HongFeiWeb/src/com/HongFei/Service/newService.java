package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.HongFei.Model.news;
import com.HongFei.Tool.DBConn;


public class newService {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	//��ʾ����ҳ��
	public 	List<news> newsHome(){
		List<news> list=new ArrayList<news>();
	
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_News where InHomePage=1");
			rs=st.executeQuery();
			while(rs.next()){
				news a=new news();
				a.setNewsid(rs.getInt("NewsId"));
				a.setTitle(rs.getString("Title"));
				a.setContent(rs.getString("Content"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setTime(rs.getString("Time"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
		
	}
	
	
	public 	List<news> news(){
		List<news> list=new ArrayList<news>();
	
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_News where CategoryId=6");
			rs=st.executeQuery();
			while(rs.next()){
				news a=new news();
				a.setNewsid(rs.getInt("NewsId"));
				a.setTitle(rs.getString("Title"));
				a.setContent(rs.getString("Content"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setTime(rs.getString("Time"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
		
	}
	 public List<news> news1(int pag){
		 try {
			
		  List s=new ArrayList();
		  
		  int sum=news().size();  //������ݿ�������
		  int x;
		  if(sum>4*pag){
			  x=4*pag;
		  }
		  else{
			  x=sum;
		  }
		  for(int i=4*(pag-1);i<x;i++){
		    	
		    	
			  List<news> userList;
				s.add(news().get(i));   
		    	
		    }
		  return s;
	   
	 } catch (Exception e) {
			// TODO: handle exception
		}
		 return null;
	 }	
	
	public 	List<news> news_2(){
		List<news> list=new ArrayList<news>();
	
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_News where CategoryId=7");
			rs=st.executeQuery();
			while(rs.next()){
				news a=new news();
				a.setNewsid(rs.getInt("NewsId"));
				a.setTitle(rs.getString("Title"));
				a.setContent(rs.getString("Content"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setTime(rs.getString("Time"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
		
	}
   
	
	public List<news> news2(int pag){
		 try {
			
		  List s=new ArrayList();
		  
		  int sum=news_2().size();  //������ݿ�������
		  int x;
		  if(sum>4*pag){
			  x=4*pag;
		  }
		  else{
			  x=sum;
		  }
		  for(int i=4*(pag-1);i<x;i++){
		    	
		    	
			  List<news> userList;
				s.add(news_2().get(i));   
		    	
		    }
		  return s;
	   
	 } catch (Exception e) {
			// TODO: handle exception
		}
		 return null;
	 }	
	
	public 	List<news> news_3(){
		List<news> list=new ArrayList<news>();
	
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_News where CategoryId=8");
			rs=st.executeQuery();
			while(rs.next()){
				news a=new news();
				a.setNewsid(rs.getInt("NewsId"));
				a.setTitle(rs.getString("Title"));
				a.setContent(rs.getString("Content"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setTime(rs.getString("Time"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
		
	}
	
	public List<news> news3(int pag){
		 try {
			
		  List s=new ArrayList();
		  
		  int sum=news_3().size();  //������ݿ�������
		  int x;
		  if(sum>4*pag){
			  x=4*pag;
		  }
		  else{
			  x=sum;
		  }
		  for(int i=4*(pag-1);i<x;i++){
		    	
		    	
			  List<news> userList;
				s.add(news_3().get(i));   
		    	
		    }
		  return s;
	   
	 } catch (Exception e) {
			// TODO: handle exception
		}
		 return null;
	 }	
}
