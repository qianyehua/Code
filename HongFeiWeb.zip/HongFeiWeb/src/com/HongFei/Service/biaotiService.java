package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.HongFei.Model.daohang;
import com.HongFei.Tool.DBConn;

public class biaotiService {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	public List<daohang> cate1(){
		List<daohang> list=new ArrayList<daohang>();
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_Category where ParentId=2");
			rs=st.executeQuery();
			while(rs.next()){
				daohang d=new daohang();
				d.setName(rs.getString("Name"));
				d.setUrl(rs.getString("url"));
				d.setCategoryid(rs.getInt("CategoryId"));
				d.setParentid(rs.getInt("ParentId"));
				list.add(d);
			}	
			
                return list;			    
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		return null;
		
	}
     
	public List<daohang> cate2(){
		List<daohang> list=new ArrayList<daohang>();
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_Category where InTitle=0 and ParentId=3");
			rs=st.executeQuery();
			while(rs.next()){
				daohang d=new daohang();
				d.setName(rs.getString("Name"));
				d.setUrl(rs.getString("url"));
				d.setCategoryid(rs.getInt("CategoryId"));
				d.setParentid(rs.getInt("ParentId"));
				list.add(d);
			}	
			
                return list;			    
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		return null;
		
	}
	public List<daohang> cate3(){
		List<daohang> list1=new ArrayList<daohang>();
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_Category where InTitle=0 and ParentId=4 and hide=1");
			rs=st.executeQuery();
			while(rs.next()){
				daohang d=new daohang();
				d.setName(rs.getString("Name"));
				d.setUrl(rs.getString("url"));
				d.setCategoryid(rs.getInt("CategoryId"));
				d.setParentid(rs.getInt("ParentId"));
				list1.add(d);
			}	
			
                return list1;			    
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		return null;
		
	}
}
