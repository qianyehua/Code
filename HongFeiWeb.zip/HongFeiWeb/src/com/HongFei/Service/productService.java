package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.HongFei.Model.news;
import com.HongFei.Model.product;
import com.HongFei.Tool.DBConn;

public class productService {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	
	//��ʾ����ҳ
	public List<product> productHome(){    //��ʾ����ҳ��
		List<product> list=new ArrayList<product>();
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_Product where InHomePage=1");
			rs=st.executeQuery();
			while(rs.next()){
				product a=new product();
				a.setProductid(rs.getInt("ProductId"));
				a.setName(rs.getString("Name"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setTime(rs.getString("Time"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
	}
	
	public List<product> product1(int id){
		List<product> list=new ArrayList<product>();
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_Product where CategoryId=?");
			st.setInt(1, id);
			rs=st.executeQuery();
			while(rs.next()){
				product a=new product();
				a.setProductid(rs.getInt("ProductId"));
				a.setName(rs.getString("Name"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setTime(rs.getString("Time"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
	}
	
	public List<product> product_1(int pag,int id){
		 try {
			
		  List s=new ArrayList();
		  
		  int sum=product1(id).size();  //������ݿ�������
		  int x;
		  if(sum>9*pag){
			  x=9*pag;
		  }
		  else{
			  x=sum;
		  }
		  for(int i=9*(pag-1);i<x;i++){
		    	
		    	
			  List<product> userList;
				s.add(product1(id).get(i));   
		    	
		    }
		  return s;
	   
	 } catch (Exception e) {
			// TODO: handle exception
		}
		 return null;
	 }	
	
	
	public List<product> product2(){
		List<product> list=new ArrayList<product>();
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_Product");
			rs=st.executeQuery();
			while(rs.next()){
				product a=new product();
				a.setProductid(rs.getInt("ProductId"));
				a.setName(rs.getString("Name"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setTime(rs.getString("Time"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
	}
	
	public List<product> product_2(int pag){
		 try {
			
		  List s=new ArrayList();
		  
		  int sum=product2().size();  //������ݿ�������
		  int x;
		  if(sum>9*pag){
			  x=9*pag;
		  }
		  else{
			  x=sum;
		  }
		  for(int i=9*(pag-1);i<x;i++){
		    	
		    	
			  List<product> userList;
				s.add(product2().get(i));   
		    	
		    }
		  return s;
	   
	 } catch (Exception e) {
			// TODO: handle exception
		}
		 return null;
	 }	
	
	public List<product> product3(){
		List<product> list=new ArrayList<product>();
		try {
			conn=new DBConn().getCon();
			st=conn.prepareStatement("select * from T_Product where CategoryId=23");
			rs=st.executeQuery();
			while(rs.next()){
				product a=new product();
				a.setProductid(rs.getInt("ProductId"));
				a.setName(rs.getString("Name"));
				a.setImgurl(rs.getString("ImgUrl"));
				a.setTime(rs.getString("Time"));
				list.add(a);
			}
			return list;
		} catch (Exception e) {
			
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
		
		return null;
	}
	
	public List<product> product_3(int pag){
		 try {
			
		  List s=new ArrayList();
		  
		  int sum=product3().size();  //������ݿ�������
		  int x;
		  if(sum>9*pag){
			  x=9*pag;
		  }
		  else{
			  x=sum;
		  }
		  for(int i=9*(pag-1);i<x;i++){
		    	
		    	
			  List<product> userList;
				s.add(product3().get(i));   
		    	
		    }
		  return s;
	   
	 } catch (Exception e) {
			// TODO: handle exception
		}
		 return null;
	 }	
}
