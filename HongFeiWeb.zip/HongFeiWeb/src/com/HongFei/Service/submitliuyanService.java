package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.HongFei.Tool.DBConn;

public class submitliuyanService {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	public int submit(String ly){
		conn=DBConn.getCon();
		try {
			st=conn.prepareStatement("insert into T_Feedback "+"(Content,Time)"+"values(?,?)" );
			
			st.setString(1, ly);
			st.setString(2, getDate());
			int i=st.executeUpdate();
			return 1;
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return 0;
	}
	private String getDate() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String date= format.format(new Date());
		return date;
	}

}
