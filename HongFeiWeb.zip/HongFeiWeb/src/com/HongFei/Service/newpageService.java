package com.HongFei.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.HongFei.Tool.DBConn;

public class newpageService {
	int i;
	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	public int page(){
		    
		conn=DBConn.getCon();
		try {
			
			st=conn.prepareStatement("select * from T_News where CategoryId=6");
		    rs =st.executeQuery();
		   
		    while(rs.next()){
		    	i++;
		    }
			return i;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
	     return 0;
	}
	
	public int page2(){
	    
		conn=DBConn.getCon();
		try {
			
			st=conn.prepareStatement("select * from T_News where CategoryId=7");
		    rs =st.executeQuery();
		   
		    while(rs.next()){
		    	i++;
		    }
			return i;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
	     return 0;
	}

	
	public int page3(){
	    
		conn=DBConn.getCon();
		try {
			
			st=conn.prepareStatement("select * from T_News where CategoryId=8");
		    rs =st.executeQuery();
		   
		    while(rs.next()){
		    	i++;
		    }
			return i;
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally{
			 DBConn a=new 	DBConn();
			 a.close(rs, st, conn);
			}
	     return 0;
	}
}
