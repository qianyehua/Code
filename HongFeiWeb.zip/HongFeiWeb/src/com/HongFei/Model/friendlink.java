package com.HongFei.Model;

public class friendlink {

	int LinkId;
	String Name;
	String ImgUrl;
	String Href;
	public int getLinkId() {
		return LinkId;
	}
	public void setLinkId(int linkId) {
		LinkId = linkId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getImgUrl() {
		return ImgUrl;
	}
	public void setImgUrl(String imgUrl) {
		ImgUrl = imgUrl;
	}
	public String getHref() {
		return Href;
	}
	public void setHref(String href) {
		Href = href;
	}
	

}
