package com.HongFei.Model;

public class daohang {

	String url;
	String Name;
	int Categoryid;
	int parentid;
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getCategoryid() {
		return Categoryid;
	}
	public void setCategoryid(int categoryid) {
		Categoryid = categoryid;
	}
	public int getParentid() {
		return parentid;
	}
	public void setParentid(int parentid) {
		this.parentid = parentid;
	}
	
	
}
