package com.Meetingroom.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.Meetingroom.Tool.DBConn;

public class SublistScriptDao {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	public JSONArray getdevice(){
		JSONArray array=new JSONArray();
		 try {
			     conn=DBConn.getCon();
				st=conn.prepareStatement("select * from Device");		
				rs=st.executeQuery();
				JSONObject m=null;
				while(rs.next()){
					 m=new JSONObject();
					m.put("deviceid",rs.getInt("deviceid"));
					m.put("device",rs.getString("device"));
					
					array.add(m);
				}
					return array;
					
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}finally{
						DBConn.closeDB(conn, st, rs);
					}
				return null;
		}
	
	public JSONArray getcapacity(){
		JSONArray array=new JSONArray();
		 try {
			     conn=DBConn.getCon();
				st=conn.prepareStatement("select distinct capacity from Room");		
				rs=st.executeQuery();
				JSONObject m=null;
				while(rs.next()){
					 m=new JSONObject();
					m.put("capacity",rs.getInt("capacity"));
					array.add(m);
				}
					return array;
					
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}finally{
						DBConn.closeDB(conn, st, rs);
					}
				return null;
		}
	public JSONArray getmeetroom(){
		JSONArray array=new JSONArray();
		try {
			conn=DBConn.getCon();
			st=conn.prepareStatement("select * from RoomType");
			rs=st.executeQuery();
			JSONObject ob=null;
			while(rs.next()){
				ob=new JSONObject();
				ob.put("typeid",rs.getInt("typeid"));
				ob.put("type", rs.getString("type"));
				array.add(ob);
			}
			
			return array;
			} catch (Exception e) {
				// TODO: handle exception
			}finally{
				DBConn.closeDB(conn, st, rs);
			}
		 return null;
	  }
	
	public JSONArray chaRoom(String sql){
		JSONArray array=new JSONArray();
		try {
			conn=DBConn.getCon();
			st=conn.prepareStatement(sql);
			rs=st.executeQuery();
			JSONObject ob=null;
			while(rs.next()){
				ob=new JSONObject();
				ob.put("roomid",rs.getInt("roomid"));
				ob.put("address", rs.getString("address"));
				ob.put("imgsrc", rs.getString("imgsrc"));
				ob.put("room", rs.getString("room"));
				array.add(ob);
			}
			   return array;
			} catch (Exception e) {
				// TODO: handle exception
			}finally{
				DBConn.closeDB(conn, st, rs);
			}
		 return null;
	  }
	
	public int RoomPage(String sql){
		JSONArray array=new JSONArray();
		try {
			conn=DBConn.getCon();
			st=conn.prepareStatement(sql);
			rs=st.executeQuery();
			int amount=0;
			while(rs.next()){
				amount++;
				
			}
			   return amount;
			} catch (Exception e) {
				// TODO: handle exception
			}finally{
				DBConn.closeDB(conn, st, rs);
			}
		 return 0;
	  }
	
	public JSONArray getFilteRoom(JSONObject o){
		
		  StringBuffer sql=new StringBuffer("select * from Room where 1=1");
		  
		  if(o.getInt("type")!=0){
			     sql.append(" and typeid="+o.getInt("type"));
		  }
	      if(o.getInt("capacity")!=0){
	    	  sql.append(" and capacity="+o.getInt("capacity"));
	      }
	      if(o.getJSONArray("device").size()>0){
	    	  
	    	  sql.append(" and roomid in("); 
	      }
	      for(int i=0;i<o.getJSONArray("device").size();i++)
	    	  sql.append("(select roomid from RoomDevice where deviceid="+o.getJSONArray("device").getInt(i)+") INTERSECT");
	      
	      if(o.getJSONArray("device").size()>0){
	       sql.append("(SELECT DISTINCT roomid  from RoomDevice))");
	      }
	      //System.out.println(sql);
	      
	      JSONArray arr=JSONArray.fromObject(chaRoom(sql.toString()));
	      return arr;
		
	}
	
	public JSONArray getFilteRoom2(int pag,JSONObject o){
		 try {
			
		 JSONArray s=new JSONArray();
		  
		  int sum=getFilteRoom(o).size();  //获得数据库总条数
		  int x;
		  if(sum>4*pag){
			  x=4*pag;
		  }
		  else{
			  x=sum;
		  }
		  for(int i=4*(pag-1);i<x;i++){
		    	
				s.add(getFilteRoom(o).get(i));   
		    	
		    }
		  return s;
	   
	 } catch (Exception e) {
			// TODO: handle exception
		}finally{
			DBConn.closeDB(conn, st, rs);
		}
		 return null;
	 }	
	
	
	public int getRoomPage(JSONObject o){
		
		  StringBuffer sql=new StringBuffer("select * from Room where 1=1");
		  
		  if(o.getInt("type")!=0){
			     sql.append(" and typeid="+o.getInt("type"));
		  }
	      if(o.getInt("capacity")!=0){
	    	  sql.append(" and capacity="+o.getInt("capacity"));
	      }
	      if(o.getJSONArray("device").size()>0){
	    	  
	    	  sql.append(" and roomid in("); 
	      }
	      for(int i=0;i<o.getJSONArray("device").size();i++)
	    	  sql.append("(select roomid from RoomDevice where deviceid="+o.getJSONArray("device").getInt(i)+") INTERSECT");
	      
	      if(o.getJSONArray("device").size()>0){
	       sql.append("(SELECT DISTINCT roomid  from RoomDevice))");
	      }
	      //System.out.println(sql);
	      
	      int amount=RoomPage(sql.toString());
	      return amount;
		
	}

	public int adduser(JSONObject message){
		try {
			conn=DBConn.getCon();
			st=conn.prepareStatement("insert into Meeting"+"(sch_starttime,sch_endtime,roomid,userid,content)"+"values(?,?,?,?,?)");
			st.setString(1,message.getString("stime"));
			st.setString(2, message.getString("etime"));
			st.setInt(3, message.getInt("roomid"));
			st.setInt(4, message.getInt("userid"));
			st.setString(5, message.getString("content"));
			
			int i=st.executeUpdate();
			
			return 1;
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			DBConn.closeDB(conn, st, rs);
		}
			
		return 0;
	}
	
	
	public int select(JSONObject message){
		try {
			conn=DBConn.getCon();
			st=conn.prepareStatement("select * from Meeting where sch_starttime>"+message.getString("date")+" and sch_starttime<"+message.getString("date")+" and sch_starttime>"+message.getString("stime")+" and sch_endtime>"+message.getString("etime")+" ");
			rs=st.executeQuery();
			int i = 0;
			while(rs.next()){
				
				i++;
			}
			
			return i;
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			DBConn.closeDB(conn, st, rs);
		}
			
		return 0;
	}
	
	
}
