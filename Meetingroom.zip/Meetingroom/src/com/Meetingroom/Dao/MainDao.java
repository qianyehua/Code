package com.Meetingroom.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.Meetingroom.Tool.DBConn;

public class MainDao {
	private Connection conn;
	private  PreparedStatement prst,prst1;
	private ResultSet rs,rs1;
	public JSONArray getyiduById(String date,String date2){
		 conn=DBConn.getCon();
		 JSONArray arr=new JSONArray();
		 try{
			 prst=conn.prepareStatement("select roomid,room from Room");
		    rs=prst.executeQuery();
		    JSONObject o=null;
		    ArrayList<String> strarray=null;
		    while(rs.next()){
		    	int id=rs.getInt("roomid");
		    	String name=rs.getString("room");
		    	o=new JSONObject();
		    	o.put("roomid", id);
		    	o.put("room", name);
		    		prst1=conn.prepareStatement("select roomid,Meeting.sch_starttime,Meeting.sch_endtime from Meeting where  Meeting.sch_starttime>'"+date+"' and Meeting.sch_starttime<'"+date2+"' and roomid="+id+"");
		    	    rs1=prst1.executeQuery();
		    	    strarray=new ArrayList<String>();
		    	    while(rs1.next()){
		    	    	strarray.add(rs1.getString("sch_starttime")+" "+rs1.getString("sch_endtime"));
		    	    }
		    	 o.put("time", strarray);
		    	 
		    	arr.add(o);
		    	}
		    return arr;
		 }catch(Exception e){
			 e.printStackTrace();
			 return null;
		 }
		 finally{
			 DBConn.closeDB(conn, prst, rs);
		 }
	 }
	public String fromDateStringToLong(String time,String mintime,String maxtime) { // 此方法计算时间毫秒
		Date date = null; // 定义时间类型
		Date date2=null;
		Date date3=null;
		SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		try {
		date = inputFormat.parse("2017-3-23"+" "+time); // 将字符型转换成日期型
		date2 = inputFormat.parse("2017-3-23"+" "+mintime); // 将字符型转换成日期型
		date3 = inputFormat.parse("2017-3-23"+" "+maxtime); // 将字符型转换成日期型
		long a=date.getTime();
		long b=date2.getTime();
		long c=date3.getTime();
		if((a-b)>=0&&(a-c<=0)){
			return "a";
		}
		return "b";
		} catch (Exception e) {
		e.printStackTrace();
		
		}
		return "b"; // 返回毫秒数
		}

	public  String getSpecifiedDayAfter(String specifiedDay){ 
		Calendar c = Calendar.getInstance(); 
		Date date=null; 
		try { 
		date = new SimpleDateFormat("yy-MM-dd").parse(specifiedDay); 
		} catch (Exception e) { 
		e.printStackTrace(); 
		} 
		c.setTime(date); 
		int day=c.get(Calendar.DATE); 
		c.set(Calendar.DATE,day+1); 

		String dayAfter=new SimpleDateFormat("yyyy-MM-dd").format(c.getTime()); 
		return dayAfter; 
		} 
	
	
}
