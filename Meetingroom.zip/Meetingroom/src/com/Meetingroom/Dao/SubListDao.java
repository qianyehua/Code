package com.Meetingroom.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.Meetingroom.Tool.DBConn;

public class SubListDao {

	Connection conn=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	public JSONArray meeting(int userid){
		JSONArray list=new JSONArray();
		 try {
			     conn=DBConn.getCon();
				st=conn.prepareStatement("select Meeting.*,room from Meeting,Room where Meeting.roomid=Room.roomid and status=0 and Meeting.userid="+userid);		
				rs=st.executeQuery();
				JSONObject m=null;
				while(rs.next()){
					 m=new JSONObject();
					m.put("Meetingid",rs.getInt("meetingid"));
					m.put("Status",rs.getInt("status"));
					m.put("Act_starttime", rs.getString("act_starttime"));
					m.put("Act_endtime" ,rs.getString("act_endtime"));
					m.put("Roomid", rs.getInt("roomid"));
					m.put("Sch_endtime", rs.getString("sch_endtime"));
					m.put("Sch_starttime", rs.getString("sch_starttime"));
					m.put("Attendance" ,rs.getInt("attendance"));
					m.put("Usreid" ,rs.getInt("userid"));
					m.put("Content" ,rs.getString("content"));
					m.put("Memo" ,rs.getString("memo"));
					m.put("Code" ,rs.getString("code"));
					m.put("Room" ,rs.getString("room"));
					list.add(m);
				}
					return list;
					
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}finally{
						DBConn.closeDB(conn, st, rs);
					}
				return null;
		}
	
	public JSONArray meeting2(int pag,int userid){
		 try {
			
		 JSONArray s=new JSONArray();
		  
		  int sum=meeting(userid).size();  //获得数据库总条数
		  int x;
		  if(sum>8*pag){
			  x=8*pag;
		  }
		  else{
			  x=sum;
		  }
		  for(int i=8*(pag-1);i<x;i++){
		    	
				s.add(meeting(userid).get(i));   
		    	
		    }
		  return s;
	   
	 } catch (Exception e) {
			// TODO: handle exception
		}finally{
			DBConn.closeDB(conn, st, rs);
		}
		 return null;
	 }	
	
	public JSONObject selectById(int meetingid){
		JSONObject m=new JSONObject();
		try{
			conn=DBConn.getCon();
			st=conn.prepareStatement("select content,memo from Meeting where meetingid="+meetingid);
			rs=st.executeQuery();
			while(rs.next()){
			
			m.put("Content",rs.getString("content"));
			m.put("Memo",rs.getString("memo"));
					
			} 
			return m;
		}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}finally{
					DBConn.closeDB(conn, st, rs);
				}
			return null;
	}
				
	public int deleteMeetingById(int id){
		try{
			conn=DBConn.getCon();
			st=conn.prepareStatement("update Meeting set status=3 where meetingid="+id);
			st.executeUpdate();
			return 1;
			}
		catch(Exception e){
			e.printStackTrace();
			
		}
		finally{
		       DBConn.closeDB(conn, st, rs);
	      }
		
		return 0;
	}
	
		
		
		public int getMeetingAmoutById(int id){
			int i;
		    int amount=0;
			try{
				conn=DBConn.getCon();
				st=conn.prepareStatement("select count(*) as amount from Meeting where status=0 and userid="+id);
				rs=st.executeQuery();
				while(rs.next()){
				 amount=rs.getInt("amount");
				}
				
				return amount;
			}catch(Exception e){
				e.printStackTrace();
			}
			finally{
				DBConn.closeDB(conn, st, rs);
			}
			return 0;
	}	
   
		public int updatememo(int id,String memo){
			try{
				conn=DBConn.getCon();
				st=conn.prepareStatement("update Meeting set memo='"+memo+"' where meetingid="+id);
				st.executeUpdate();
				return 1;
				}
			catch(Exception e){
				e.printStackTrace();
				
			}
			finally{
			       DBConn.closeDB(conn, st, rs);
		      }
			
			return 0;
		}


}