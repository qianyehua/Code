package com.Meetingroom.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Meetingroom.Tool.DBConn;

import net.sf.json.JSONObject;

public class LoginDao {
	 private Connection conn;
	   private PreparedStatement prst;
	   private ResultSet rs;
	   
	public JSONObject islogin(String username,String userpwd){
		conn=DBConn.getCon();
		try {
			prst=conn.prepareStatement("select username,userpwd from Users where username=? and userpwd=?");
			prst.setString(1, username);
			prst.setString(2, userpwd);
			rs=prst.executeQuery();
			while(rs.next()){
				JSONObject o= new JSONObject();
				o.put("username", rs.getString("username"));
				o.put("userpwd", rs.getString("userpwd"));
				return o;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBConn.closeDB(conn, prst, rs);
		}
		return null;
	}
	
	
	public int loginUserid(String username){
		conn=DBConn.getCon();
		try {
			prst=conn.prepareStatement("select userid from Users where username=?");
			prst.setString(1, username);
			rs=prst.executeQuery();
			while(rs.next()){
				
				int userid=rs.getInt("userid");
				return userid;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBConn.closeDB(conn, prst, rs);
		}
		return 0;
	}

	}
