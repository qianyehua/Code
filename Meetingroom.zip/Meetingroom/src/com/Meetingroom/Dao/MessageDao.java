package com.Meetingroom.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.Meetingroom.Tool.DBConn;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class MessageDao {

	private Connection conn;
	private  PreparedStatement prst;
	private ResultSet rs;
		
 public JSONArray  getimformtype(){
	 conn=DBConn.getCon();
	 JSONArray arr=new JSONArray();
	try{
		prst=conn.prepareStatement("select * from InformType");
		rs=prst.executeQuery();
		JSONObject o=null;
		while(rs.next()){
			o=new JSONObject();
			o.put("type",rs.getString("type"));
			o.put("typeid",rs.getInt("typeid"));
			arr.add(o);
		}
		return arr;
	}catch(Exception e){
			e.printStackTrace();
			
		}
		finally{
		DBConn.closeDB(conn, prst, rs);
	} 
	return null;
 }
 
 public JSONArray getyiduById(int typeid,int userid){
	 conn=DBConn.getCon();
	 JSONArray arr=new JSONArray();
	 try{
		 prst=conn.prepareStatement("select * from Inform where typeid="+typeid+" and userid="+userid+" and status=1");
	    rs=prst.executeQuery();
	    JSONObject o=null;
	    while(rs.next()){
	    	o=new JSONObject();
	    	o.put("informid", rs.getInt("informid"));
	    	o.put("content", rs.getString("content"));
	    	o.put("status", rs.getInt("status"));
	    	o.put("time", rs.getString("time"));
	    	arr.add(o);
	    	}
	    return arr;
	 }catch(Exception e){
		 e.printStackTrace();
		 return null;
	 }
	 finally{
		 DBConn.closeDB(conn, prst, rs);
	 }
 }
 
 public JSONArray getweiduById(int typeid,int userid){
	 conn=DBConn.getCon();
	 JSONArray arr=new JSONArray();
	 try{
		 prst=conn.prepareStatement("select * from Inform where typeid="+typeid+" and userid="+userid+" and status=0");
	    rs=prst.executeQuery();
	    JSONObject o=null;
	    while(rs.next()){
	    	o=new JSONObject();
	    	o.put("informid", rs.getInt("informid"));
	    	o.put("content", rs.getString("content"));
	    	o.put("status", rs.getInt("status"));
	    	o.put("time", rs.getString("time"));
	    	arr.add(o);
	    	}
	    return arr;
	 }catch(Exception e){
		 e.printStackTrace();
		 return null;
	 }
	 finally{
		 DBConn.closeDB(conn, prst, rs);
	 }
 }
 
 public JSONArray getimformById2(int pag,int typeid,int userid){
	   JSONArray s=new JSONArray();
	  int sum=getyiduById(typeid,userid).size()+getweiduById(typeid, userid).size();//获得数据库总条数
	  int x;
	  
	try {
	  if(sum>7*pag){
		  x=7*pag;
	  }
	  else{
		  x=sum;
	  }
	  JSONArray a1=getweiduById(typeid,userid);
	  JSONArray a2=getyiduById(typeid,userid);
	  a1.addAll(a2);
	 
	  for(int i=7*(pag-1);i<x;i++){
		    s.add(a1.get(i));
	  }  	
	    
	  return s;
   
 } catch (Exception e) {
		// TODO: handle exception
	}finally{
		DBConn.closeDB(conn, prst, rs);
	}
	 return null;
 }	
 
 public int gettypeAmountById(int typeid,int userid){
	 conn=DBConn.getCon();
	 int Amount=0;
	 try{
		 prst=conn.prepareStatement("select count(*) as Amount from Inform where typeid="+typeid+" and userid="+userid+" and status=0");
		 rs=prst.executeQuery();
		 while(rs.next()){
			 Amount=rs.getInt("Amount");
		 }
		 return Amount;
	 }catch(Exception e){
		 e.printStackTrace();
	 }
	 finally{
		 DBConn.closeDB(conn, prst, rs);
	 }
	 return 0;
 }
 
 public int getpageById(int typeid,int userid){
	 conn=DBConn.getCon();
	 int Amount=0;
	 try{
		 prst=conn.prepareStatement("select count(*) as Amount from Inform where typeid="+typeid+" and userid="+userid+"");
		 rs=prst.executeQuery();
		 while(rs.next()){
			 Amount=rs.getInt("Amount");
		 }
		 return Amount;
	 }catch(Exception e){
		 e.printStackTrace();
	 }
	 finally{
		 DBConn.closeDB(conn, prst, rs);
	 }
	 return 0;
 }
 
 public int getinformById(int userid){
	 conn=DBConn.getCon();
	 int Amount=0;
	 try{
		 prst=conn.prepareStatement("select count(*) as Amount from Inform where userid="+userid+" and status=0");
		 rs=prst.executeQuery();
		 while(rs.next()){
			 Amount=rs.getInt("Amount");
		 }
		 return Amount;
	 }catch(Exception e){
		 e.printStackTrace();
	 }
	 finally{
		 DBConn.closeDB(conn, prst, rs);
	 }
	 return 0;
 }
    
 
 public int deleinformById(int id){
		try{
			conn=DBConn.getCon();
			prst=conn.prepareStatement("delete from Inform where informid="+id);
			prst.executeUpdate();
			return 1;
			}
		catch(Exception e){
			e.printStackTrace();
			
		}
		finally{
		       DBConn.closeDB(conn, prst, rs);
	      }
		
		return 0;
	}
 
 public int upeinformById(int id){
		try{
			conn=DBConn.getCon();
			prst=conn.prepareStatement("update Inform set status=1 where informid="+id);
			prst.executeUpdate();
			return 1;
			}
		catch(Exception e){
			e.printStackTrace();
			
		}
		finally{
		       DBConn.closeDB(conn, prst, rs);
	      }
		
		return 0;
	}
 public int upeinformById2(int id){
		try{
			conn=DBConn.getCon();
			prst=conn.prepareStatement("update Inform set status=0 where informid="+id);
			prst.executeUpdate();
			return 1;
			}
		catch(Exception e){
			e.printStackTrace();
			
		}
		finally{
		       DBConn.closeDB(conn, prst, rs);
	      }
		
		return 0;
	}
}