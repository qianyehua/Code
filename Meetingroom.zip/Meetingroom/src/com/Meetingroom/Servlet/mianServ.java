package com.Meetingroom.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Meetingroom.Dao.MainDao;
import com.Meetingroom.Tool.InTime;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class mianServ extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public mianServ() {
		super();
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		MainDao a=new MainDao();
		String date=request.getParameter("date");
		String date2=a.getSpecifiedDayAfter(date);
		
		JSONArray array=new JSONArray();
		JSONArray arr=new JSONArray();
		ArrayList<String> ayy=null;
		
//		String s1="2017-03-21";
//		String s2="2017-03-22";
		arr=a.getyiduById(date,date2);
//		System.out.println(arr);
		for(int i=0;i<arr.size();i++){
			JSONObject o=new JSONObject();
			o.put("name",((JSONObject)arr.get(i)).get("room"));
			JSONArray s=(JSONArray) ((JSONObject)arr.get(i)).get("time");
			ayy=new ArrayList<String>();
			if(s.size()==0){
				for(int n=0;n<18;n++){
				ayy.add(n,"b");
				}
			}
			else{
			for(int m=0;m<s.size();m++){
				String t=s.getString(m);
				String t2=t.substring(11,16);
				String t3=t.substring(28,33);
//				System.out.println(t2);
//				System.out.println(t3);
//				System.out.println(a.fromDateStringToLong("9:00", t2, t3));
//					ayy.set(0,0);
//					ayy.s
					ayy.add(0,a.fromDateStringToLong("9:01", t2, t3));
					ayy.add(1,a.fromDateStringToLong("9:31", t2, t3));
					ayy.add(2,a.fromDateStringToLong("10:01", t2, t3));
					ayy.add(3,a.fromDateStringToLong("10:31", t2, t3));
					ayy.add(4,a.fromDateStringToLong("11:01", t2, t3));
					ayy.add(5,a.fromDateStringToLong("11:31", t2, t3));
					ayy.add(6,a.fromDateStringToLong("12:01", t2, t3));
					ayy.add(7,a.fromDateStringToLong("12:31", t2, t3));
					ayy.add(8,a.fromDateStringToLong("13:01", t2, t3));
					ayy.add(9,a.fromDateStringToLong("13:31", t2, t3));
					ayy.add(10,a.fromDateStringToLong("14:01", t2, t3));
					ayy.add(11,a.fromDateStringToLong("14:31", t2, t3));
					ayy.add(12,a.fromDateStringToLong("15:01", t2, t3));
					ayy.add(13,a.fromDateStringToLong("15:31", t2, t3));
					ayy.add(14,a.fromDateStringToLong("16:01", t2, t3));
					ayy.add(15,a.fromDateStringToLong("16:31", t2, t3));
					ayy.add(16,a.fromDateStringToLong("17:01", t2, t3));
					ayy.add(17,a.fromDateStringToLong("17:30", t2, t3));
			 }
			}
			o.put("time", ayy);
			array.add(o);
//			System.out.println(ayy);
			
		 }
		System.out.println(array);
		PrintWriter out = response.getWriter();
		out.print(array);
		out.flush();
		out.close();
	}

}
