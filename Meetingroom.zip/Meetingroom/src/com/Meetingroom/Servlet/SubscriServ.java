package com.Meetingroom.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Meetingroom.Dao.SublistScriptDao;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class SubscriServ extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public SubscriServ() {
		super();
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		int type,capacity;
	    try {
	    	 type=Integer.parseInt(request.getParameter("room"));
		} catch (Exception e) {
			type=0;
		}
	    try {
	    	capacity=Integer.parseInt(request.getParameter("renshu"));
		} catch (Exception e) {
			capacity=0;
		}
		
		String[] checkbox= request.getParameterValues("type");
		JSONArray arr=new JSONArray();
		if(checkbox!=null){
			 arr=JSONArray.fromObject(checkbox);
		}
		int page=Integer.parseInt(request.getParameter("page"));
//		 String typeString="";
//		 
//		 for(int i =0;i<checkbox.length;i++) //对checkbox进行遍历  
//		 {  
//		 typeString+=checkbox[i]+",";  
//		 }  
//		 typeString=typeString.substring(0,typeString.length()-1);
		 JSONObject o=new JSONObject();
		 o.put("type", type);
		 o.put("capacity",capacity);
		 o.put("device", arr);
		 JSONArray array=new JSONArray();
		 SublistScriptDao a=new SublistScriptDao();
		 array=a.getFilteRoom2(page,o);
		PrintWriter out = response.getWriter();
		out.print(array);
		out.flush();
		out.close();
	}

}
