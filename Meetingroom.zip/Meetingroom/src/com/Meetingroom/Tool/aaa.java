package com.Meetingroom.Tool;

import java.util.ArrayList;
import java.util.Date;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.Meetingroom.Dao.HistoryDao;
import com.Meetingroom.Dao.MainDao;
import com.Meetingroom.Dao.MessageDao;
import com.Meetingroom.Dao.SublistScriptDao;

public class aaa {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JSONArray array=new JSONArray();
		JSONArray arr=new JSONArray();
		ArrayList<String> ayy=null;
		MainDao a=new MainDao();
		InTime b=new InTime();
		String s1="2017-03-21";
		String s2=a.getSpecifiedDayAfter(s1);
//		String s2="2017-03-22";
		System.out.println(s2);
		arr=a.getyiduById(s1,s2);
//		System.out.println(arr);
		for(int i=0;i<arr.size();i++){
			JSONObject o=new JSONObject();
			o.put("name",((JSONObject)arr.get(i)).get("room"));
			JSONArray s=(JSONArray) ((JSONObject)arr.get(i)).get("time");
			ayy=new ArrayList<String>();
			if(s.size()==0){
				for(int n=0;n<18;n++){
				ayy.add(n,"b");
				}
			}
			else{
			for(int m=0;m<s.size();m++){
				String t=s.getString(m);
				String t2=t.substring(11,16);
				String t3=t.substring(28,33);
//				System.out.println(t2);
//				System.out.println(t3);
//				System.out.println(a.fromDateStringToLong("9:00", t2, t3));
//					ayy.set(0,0);
//					ayy.s
					ayy.add(0,a.fromDateStringToLong("9:00", t2, t3));
					ayy.add(1,a.fromDateStringToLong("9:30", t2, t3));
					ayy.add(2,a.fromDateStringToLong("10:00", t2, t3));
					ayy.add(3,a.fromDateStringToLong("10:30", t2, t3));
					ayy.add(4,a.fromDateStringToLong("11:00", t2, t3));
					ayy.add(5,a.fromDateStringToLong("11:30", t2, t3));
					ayy.add(6,a.fromDateStringToLong("12:00", t2, t3));
					ayy.add(7,a.fromDateStringToLong("12:30", t2, t3));
					ayy.add(8,a.fromDateStringToLong("13:00", t2, t3));
					ayy.add(9,a.fromDateStringToLong("13:30", t2, t3));
					ayy.add(10,a.fromDateStringToLong("14:00", t2, t3));
					ayy.add(11,a.fromDateStringToLong("14:30", t2, t3));
					ayy.add(12,a.fromDateStringToLong("15:00", t2, t3));
					ayy.add(13,a.fromDateStringToLong("15:30", t2, t3));
					ayy.add(14,a.fromDateStringToLong("16:00", t2, t3));
					ayy.add(15,a.fromDateStringToLong("16:30", t2, t3));
					ayy.add(16,a.fromDateStringToLong("17:00", t2, t3));
					ayy.add(17,a.fromDateStringToLong("17:30", t2, t3));
			 }
			}
			o.put("time", ayy);
			array.add(o);
//			System.out.println(ayy);
			
		}
		System.out.println(array);
		}
//		long s=a.fromDateStringToLong("12:00","11:00","13:00");
//		System.out.println(s);
	
//		for(int i=0;i<arr.size();i++){
//			ob.put("room",((JSONObject) arr.get(i)).get("room"));
//			JSONObject o=(JSONObject) arr.get(i);
//			int t=o.getInt("roomid");
//			for(int n=0;n<arr.size();n++){
//				int t2=((JSONObject) arr.get(i)).getInt("roomid");
//				if(t==t2){
//					JSONArray ayy=new JSONArray();
//				    String s=((JSONObject)arr.get(n)).getString("stime").substring(11,16);
//					System.out.println(s);
//				}
//			}
//		}
	

}
